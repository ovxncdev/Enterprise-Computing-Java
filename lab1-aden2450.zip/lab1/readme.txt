JobID: cp630oc-lab1
Name: Adeniyi Ridwan Adetunji
ID: 245852450


Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab1

T1 WildFly (JBoss-AS)
T1.1 [2/2/*] WildFly installation
T1.2 [2/2/*] Set users

T2 Build and Deploy Applications by Maven
T2.1 [2/2/*] Install quickstart projects
T2.2 [2/2/*] Testing helloworld project
T2.3 [2/2/*] Testing ejb-remote project
T2.4 [2/2/*] Testing ejb-security project

T3 WildFly with Eclipse JEE
T3.1 [2/2/*] Eclipse with External WildFly
T3.2 [2/2/*] WildFly within Eclipse
T3.3 [5/5/*] ec-web Maven project

T4 JEE application project
T4.1 [2/2/*] ec-app project
T4.2 [5/5/*] ec-ejb project
T4.3 [3/3/*] ec-ejb-web project
T4.4 [3/3/*] ec-ear project
T4.5 [3/3/*] ec-app-client project
T4.6 [3/3/*] Deploy ec-ejb with remote access

Total: [40/40/*]