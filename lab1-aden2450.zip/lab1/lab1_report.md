# LAB1 Report

Author: ADENIYI RIDWAN ADETUNJI 

Date: 2025-09-23 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
# T1 WildFly (JBoss-AS) (lab practice)


### T1.1 WildFly installation
 

Complete? Yes 

![wildfly](images/wildfly.png){width=90%}


### T1.2 Set users
 

Complete? Yes 

![adduser](images/adduser.png){width=90%}



# T2 Build and Deploy Applications by Maven (lab practice)


### T2.1 Install quickstart projects
 

Complete? Yes 

![installquickstart](images/installquickstart.png){width=90%}


### T2.2 Testing helloworld project
 

Complete? Yes 

![helloworld](images/helloworld.png){width=90%}


### T2.3 Testing ejb-remote project
 

Complete? Yes 


![ejb-remote](images/ejb-remote.png){width=90%}


### T2.4 Testing ejb-security project
 

Complete?  Yes 

![ejbsec](images/ejbsec.png){width=90%}


# T3 WildFly with Eclipse JEE (lab practice)


### T3.1 Eclipse with External WildFly
 

Complete? Yes 

![ec-app](images/ec-app.png){width=90%}


### T3.2 WildFly within Eclipse
 

Complete? Yes 

![WildFly-within-Eclipse](images/WildFly-within-Eclipse.png){width=90%}



### T3.3 ec-web Maven project
 

Complete? Yes 

![ec-web-Maven-project](images/ec-web-Maven-project.png){width=90%}



# T4 JEE application project (lab practice)


### T4.1 ec-app project
 

Complete? Yes 

![ec-app-folder](images/ec-app-folder.png){width=90%}


### T4.2 ec-ejb project
 

Complete? Yes 

![ec-web-Maven-project-folder](images/ec-web-Maven-project-folder.png){width=90%}


### T4.3 ec-ejb-web project
 

Complete? Yes 

![ec-ejb-web-project-folder](images/ec-ejb-web-project-folder.png){width=90%}


### T4.4 ec-ear project
 

Complete? Yes 

![ec-earproject](images/ec-earproject.png){width=90%}


### T4.5 ec-app-client project
 

Complete? Yes 

![ec-app-clientproject](images/ec-app-clientproject.png){width=90%}



### T4.6 Deploy ec-ejb with remote access
 

Complete? Yes 


![ec-ejbwithremoteaccess](images/ec-ejbwithremoteaccess.png){width=90%}



**References**

1. CP630OC lab1

