package ec.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot application for Ranking microservice.
 * Scans both ec.springboot and ec.spring packages for components.
 */
@SpringBootApplication(scanBasePackages = {"ec.springboot", "ec.spring"})
public class RankApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(RankApplication.class, args);
        System.out.println("\n===========================================");
        System.out.println("Rank Spring Boot Microservice Started!");
        System.out.println("===========================================");
        System.out.println("Access URLs:");
        System.out.println("  http://localhost:8080/grade/76");
        System.out.println("  http://localhost:8080/rank/76");
        System.out.println("  http://localhost:8080/grade-rank/76");
        System.out.println("  http://localhost:8080/index-ms.html");
        System.out.println("===========================================\n");
    }
}