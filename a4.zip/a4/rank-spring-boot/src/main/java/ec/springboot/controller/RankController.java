package ec.springboot.controller;

import ec.spring.Rank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for ranking queries.
 * Provides endpoints for grade, rank, and combined queries.
 */
@RestController
public class RankController {
    
    @Autowired
    private Rank rank;
    
    /**
     * Get letter grade for a score.
     * 
     * Example: GET /grade/76
     * Response: {"grade":"B"}
     * 
     * @param score the score to grade
     * @return JSON with grade
     */
    @GetMapping("/grade/{score}")
    public Map<String, Object> getGrade(@PathVariable int score) {
        Map<String, Object> response = new HashMap<>();
        String grade = rank.getGrade(score);
        response.put("grade", grade);
        return response;
    }
    
    /**
     * Get rank for a score.
     * 
     * Example: GET /rank/76
     * Response: {"rank":22}
     * 
     * @param score the score to rank
     * @return JSON with rank
     */
    @GetMapping("/rank/{score}")
    public Map<String, Object> getRank(@PathVariable int score) {
        Map<String, Object> response = new HashMap<>();
        int rankValue = rank.getRank(score);
        response.put("rank", rankValue);
        return response;
    }
    
    /**
     * Get both grade and rank for a score.
     * 
     * Example: GET /grade-rank/76
     * Response: {"grade":"B","rank":22}
     * 
     * @param score the score to grade and rank
     * @return JSON with grade and rank
     */
    @GetMapping("/grade-rank/{score}")
    public Map<String, Object> getGradeAndRank(@PathVariable int score) {
        Map<String, Object> response = new HashMap<>();
        String grade = rank.getGrade(score);
        int rankValue = rank.getRank(score);
        response.put("grade", grade);
        response.put("rank", rankValue);
        return response;
    }
    
    /**
     * Root endpoint with welcome message.
     * 
     * @return JSON with welcome message
     */
    @GetMapping("/")
    public Map<String, Object> home() {
        Map<String, Object> response = new HashMap<>();
        response.put("service", "Rank Spring Boot Microservice");
        response.put("version", "1.0.0");
        response.put("endpoints", new String[]{
            "/grade/{score}",
            "/rank/{score}",
            "/grade-rank/{score}",
            "/index-ms.html"
        });
        return response;
    }
}