package ec.springboot.config;

import ec.spring.Grade;
import ec.spring.GradeImpl;
import ec.spring.Rank;
import ec.spring.RankImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring configuration class for Grade and Rank beans.
 * Replaces XML configuration with Java-based configuration.
 */
@Configuration
public class RankConfig {
    
    /**
     * Create Grade bean.
     * @return Grade instance
     */
    @Bean
    public Grade grade() {
        GradeImpl grade = new GradeImpl();
        grade.setName("Grade in Microservice");
        return grade;
    }
    
    /**
     * Create Rank bean with Grade dependency injected.
     * @return Rank instance
     */
    @Bean
    public Rank rank() {
        RankImpl rank = new RankImpl();
        rank.setName("Rank in Microservice");
        rank.setGrade(grade());  // Inject Grade bean
        return rank;
    }
}