# A4 Report

Author: Adeniyi Ridwan Adetunji 

Date: 2025-11-11 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Spring Framework for EC (programming)


### Q1.1 Grade Spring Bean

Complete? Yes 

![gradespringbean](images/gradespringbean.png){width=90%}



### Q1.2 Rank Spring Bean

Complete? Yes 

![rankspringbean](images/rankspringbean.png){width=90%}


### Q1.3 Rank Spring boot microservice

Complete? Yes 


![onethree](images/onethree.png){width=90%}


## Q2 OSGi for EC (programming)


### Q2.1 stats-osgi-service

Complete? Yes

![statosgiforec](images/statosgiforec.png){width=90%}



### Q2.2 stats-osgi-consumer

Complete? Yes 

![stats-osgi-consumer](images/stats-osgi-consumer.png){width=90%}



### Q2.3 stats-osgi-web

Complete? Yes 


![stats-osgi-web](images/stats-osgi-web.png){width=90%}



## Q3 Microservices on Docker (programming)


### Q3.1 Spring Boot microservice on Docker

Complete? Yes 

![SBmicroserviceonDOcker](images/SBmicroserviceonDOcker.png){width=90%}



### Q3.2 Python microservice on Docker

Complete? Yes 

![pythondocker](images/pythondocker.png){width=90%}



## Q4 Batch test (test)


### Q4.1  Create test output

Complete? Yes or No 

[test output](test_output.txt)





**References**

1. CP630OC a4
2. Add your references if you used any. 
