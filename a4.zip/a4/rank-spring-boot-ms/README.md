\# Rank Spring Boot Microservice on Docker



\## Prerequisites

\- Docker Desktop installed and running

\- rank-spring-boot.jar file



\## Project Structure

```

rank-spring-boot-ms/

├── rank-spring-boot.jar

├── Dockerfile

└── README.md

```



\## Build Docker Image

```bash

docker build -t rank-spring-boot-ms .

```



\## Run Docker Container

```bash

docker run -d -p 8080:8080 --name rank-predictor rank-spring-boot-ms

```



Options:

\- `-d`: Run in detached mode (background)

\- `-p 8080:8080`: Map port 8080 (host:container)

\- `--name rank-predictor`: Container name



\## Test the Service



\### Test 1: Get grade

```bash

curl http://localhost:8080/grade/76

```

Expected: `{"grade":"C"}`



\### Test 2: Get rank

```bash

curl http://localhost:8080/rank/76

```

Expected: `{"rank":22}`



\### Test 3: Get both grade and rank

```bash

curl http://localhost:8080/grade-rank/76

```

Expected: `{"grade":"C","rank":22}`



\### Test 4: Web interface

Open browser: http://localhost:8080/index-ms.html



\## Docker Management



\### View logs

```bash

docker logs rank-predictor

```



\### Stop container

```bash

docker stop rank-predictor

```



\### Start container

```bash

docker start rank-predictor

```



\### Remove container

```bash

docker rm -f rank-predictor

```



\### Remove image

```bash

docker rmi rank-spring-boot-ms

```



\## Troubleshooting



\### Port 8080 already in use

```bash

\# Use different port

docker run -d -p 8081:8080 --name rank-predictor rank-spring-boot-ms

\# Test at: http://localhost:8081/grade/76

```



\### Container exits immediately

```bash

\# Check logs

docker logs rank-predictor

```

