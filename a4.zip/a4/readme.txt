JobID: cp630oc-a4
Name: Adeniyi Ridwan Adetunji
ID: 245852450

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A4

Q1 Spring Framework for EC
Q1.1 [10/10/*] Grade Spring Bean                       
Q1.2 [15/15/*] Rank Spring Bean                        
Q1.3 [15/15/*] Rank Spring boot microservice           

Q2 OSGi for EC
Q2.1 [20/20/*] stats-osgi-service                      
Q2.2 [10/10/*] stats-osgi-consumer                     
Q2.3 [10/10/*] stats-osgi-web                          

Q3 Microservices on Docker
Q3.1 [10/10/*] Spring Boot microservice on Docker      
Q3.2 [10/10/*] Python microservice on Docker           

Q4 Batch test
Q4.1 [0/0/*]  Create test output                     

Total: [100/100/*]

