package ec.osgi.service;

import java.io.Serializable;

/**
 * Statistics summary data class.
 * This should match the StatsSummary from Assignment 3.
 */
public class StatsSummary implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int count;
    private double min;
    private double max;
    private double mean;
    private double std;
    
    public StatsSummary() {
    }
    
    public StatsSummary(int count, double min, double max, double mean, double std) {
        this.count = count;
        this.min = min;
        this.max = max;
        this.mean = mean;
        this.std = std;
    }
    
    public int getCount() {
        return count;
    }
    
    public void setCount(int count) {
        this.count = count;
    }
    
    public double getMin() {
        return min;
    }
    
    public void setMin(double min) {
        this.min = min;
    }
    
    public double getMax() {
        return max;
    }
    
    public void setMax(double max) {
        this.max = max;
    }
    
    public double getMean() {
        return mean;
    }
    
    public void setMean(double mean) {
        this.mean = mean;
    }
    
    public double getSTD() {
        return std;
    }
    
    public void setSTD(double std) {
        this.std = std;
    }
    
    @Override
    public String toString() {
        return "StatsSummary{" +
                "count=" + count +
                ", min=" + min +
                ", max=" + max +
                ", mean=" + mean +
                ", std=" + std +
                '}';
    }
}