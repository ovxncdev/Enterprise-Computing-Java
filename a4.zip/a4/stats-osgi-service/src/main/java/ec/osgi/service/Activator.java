package ec.osgi.service;

import ec.osgi.service.impl.StatsOSGiImpl;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

/**
 * OSGi Bundle Activator for Stats service.
 * Registers the StatsOSGi service when bundle starts.
 */
public class Activator implements BundleActivator {
    
    private ServiceRegistration<?> registration;
    
    @Override
    public void start(BundleContext context) throws Exception {
        System.out.println("Starting Stats OSGi Service Bundle...");
        
        // Create service instance
        StatsOSGi service = new StatsOSGiImpl();
        
        // Register service
        registration = context.registerService(
            StatsOSGi.class.getName(),
            service,
            null
        );
        
        System.out.println("Stats OSGi Service registered successfully!");
    }
    
    @Override
    public void stop(BundleContext context) throws Exception {
        System.out.println("Stopping Stats OSGi Service Bundle...");
        
        if (registration != null) {
            registration.unregister();
            registration = null;
        }
        
        System.out.println("Stats OSGi Service unregistered.");
    }
}