package ec.osgi.service.impl;

import ec.osgi.service.StatsOSGi;
import ec.osgi.service.StatsSummary;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

/**
 * Implementation of StatsOSGi service.
 * Loads StatsSummary from serialized file.
 */
public class StatsOSGiImpl implements StatsOSGi {
    
    private StatsSummary ss;
    private static final String MODEL_FILE = "C:/enterprise/tmp/model/stats.bin";
    
    /**
     * Constructor - loads StatsSummary from file.
     */
    public StatsOSGiImpl() {
        loadStatsSummary();
    }
    
    /**
     * Load StatsSummary object from serialized file.
     */
    private void loadStatsSummary() {
        try (FileInputStream fis = new FileInputStream(MODEL_FILE);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            
            ss = (StatsSummary) ois.readObject();
            System.out.println("StatsSummary loaded successfully from: " + MODEL_FILE);
            System.out.println("Loaded data: " + ss);
            
        } catch (Exception e) {
            System.err.println("Error loading StatsSummary from " + MODEL_FILE);
            e.printStackTrace();
            
            // Initialize with default values if file not found
            ss = new StatsSummary(0, 0.0, 0.0, 0.0, 0.0);
            System.out.println("Initialized with default StatsSummary");
        }
    }
    
    @Override
    public int getCount() {
        return ss.getCount();
    }
    
    @Override
    public double getMin() {
        return ss.getMin();
    }
    
    @Override
    public double getMax() {
        return ss.getMax();
    }
    
    @Override
    public double getMean() {
        return ss.getMean();
    }
    
    @Override
    public double getSTD() {
        return ss.getSTD();
    }
}