package ec.osgi.util;

import ec.osgi.service.StatsSummary;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

/**
 * Utility to create a stats.bin file with sample data.
 * Run this once to populate the stats.bin file.
 */
public class CreateStatsBin {
    
    public static void main(String[] args) {
        // Create sample statistics
        StatsSummary stats = new StatsSummary();
        stats.setCount(100);
        stats.setMin(5.0);
        stats.setMax(95.0);
        stats.setMean(50.5);
        stats.setSTD(25.8);
        
        // Save to file
        String filePath = "C:/enterprise/tmp/model/stats.bin";
        
        try {
            // Create directory if it doesn't exist
            java.io.File dir = new java.io.File("C:/enterprise/tmp/model");
            if (!dir.exists()) {
                dir.mkdirs();
                System.out.println("Created directory: " + dir.getAbsolutePath());
            }
            
            // Write object to file
            try (FileOutputStream fos = new FileOutputStream(filePath);
                 ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                
                oos.writeObject(stats);
                System.out.println("Successfully created stats.bin at: " + filePath);
                System.out.println("Statistics saved:");
                System.out.println("  Count: " + stats.getCount());
                System.out.println("  Min:   " + stats.getMin());
                System.out.println("  Max:   " + stats.getMax());
                System.out.println("  Mean:  " + stats.getMean());
                System.out.println("  STD:   " + stats.getSTD());
            }
            
        } catch (Exception e) {
            System.err.println("Error creating stats.bin: " + e.getMessage());
            e.printStackTrace();
        }
    }
}