package ec.osgi.service;

/**
 * OSGi service interface for statistics operations.
 */
public interface StatsOSGi {
    /**
     * Get the count of data values.
     * @return count
     */
    int getCount();
    
    /**
     * Get the minimum value.
     * @return minimum
     */
    double getMin();
    
    /**
     * Get the maximum value.
     * @return maximum
     */
    double getMax();
    
    /**
     * Get the mean (average) value.
     * @return mean
     */
    double getMean();
    
    /**
     * Get the standard deviation.
     * @return standard deviation
     */
    double getSTD();
}