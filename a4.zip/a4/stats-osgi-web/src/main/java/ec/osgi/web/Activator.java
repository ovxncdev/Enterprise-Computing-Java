package ec.osgi.web;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.http.HttpService;

/**
 * OSGi Bundle Activator for Stats web bundle.
 * Registers servlet with HTTP service.
 */
public class Activator implements BundleActivator {
    
    private HttpService httpService;
    
    @Override
    public void start(BundleContext context) throws Exception {
        System.out.println("Starting Stats OSGi Web Bundle...");
        
        // Get HTTP service
        ServiceReference<HttpService> httpServiceRef = 
            context.getServiceReference(HttpService.class);
        
        if (httpServiceRef != null) {
            httpService = context.getService(httpServiceRef);
            
            if (httpService != null) {
                // Register servlet
                StatsServlet servlet = new StatsServlet(context);
                httpService.registerServlet("/stats-osgi/stats", servlet, null, null);
                
                // Register static resources
                httpService.registerResources("/stats-osgi", "/web", null);
                
                System.out.println("Stats servlet registered at: /stats-osgi/stats");
                System.out.println("Static resources registered at: /stats-osgi/");
                System.out.println("Access at: http://localhost:8181/stats-osgi/index-osgi.html");
            } else {
                System.err.println("Failed to get HTTP service!");
            }
        } else {
            System.err.println("HTTP service reference not found!");
        }
        
        System.out.println("Stats OSGi Web Bundle started.");
    }
    
    @Override
    public void stop(BundleContext context) throws Exception {
        System.out.println("Stopping Stats OSGi Web Bundle...");
        
        if (httpService != null) {
            try {
                httpService.unregister("/stats-osgi/stats");
                httpService.unregister("/stats-osgi");
                System.out.println("Stats servlet and resources unregistered.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        System.out.println("Stats OSGi Web Bundle stopped.");
    }
}