package ec.osgi.web;

import ec.osgi.service.StatsOSGi;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet for handling stats queries via RESTful API.
 */
public class StatsServlet extends HttpServlet {
    
    private BundleContext bundleContext;
    
    public StatsServlet(BundleContext bundleContext) {
        this.bundleContext = bundleContext;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Get StatsOSGi service
            ServiceReference<StatsOSGi> serviceRef = 
                bundleContext.getServiceReference(StatsOSGi.class);
            
            if (serviceRef == null) {
                out.println("{\"error\": \"StatsOSGi service not found\"}");
                response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
                return;
            }
            
            StatsOSGi statsService = bundleContext.getService(serviceRef);
            
            if (statsService == null) {
                out.println("{\"error\": \"Failed to get StatsOSGi service\"}");
                response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
                return;
            }
            
            // Get query parameter
            String query = request.getParameter("query");
            
            if (query == null || query.isEmpty()) {
                // Return all stats
                out.println("{");
                out.println("  \"count\": " + statsService.getCount() + ",");
                out.println("  \"min\": " + statsService.getMin() + ",");
                out.println("  \"max\": " + statsService.getMax() + ",");
                out.println("  \"mean\": " + statsService.getMean() + ",");
                out.println("  \"std\": " + statsService.getSTD());
                out.println("}");
            } else {
                // Return specific stat based on query
                switch (query.toLowerCase()) {
                    case "count":
                        out.println("{\"count\": " + statsService.getCount() + "}");
                        break;
                    case "min":
                        out.println("{\"min\": " + statsService.getMin() + "}");
                        break;
                    case "max":
                        out.println("{\"max\": " + statsService.getMax() + "}");
                        break;
                    case "mean":
                        out.println("{\"mean\": " + statsService.getMean() + "}");
                        break;
                    case "std":
                        out.println("{\"std\": " + statsService.getSTD() + "}");
                        break;
                    default:
                        out.println("{\"error\": \"Unknown query: " + query + "\"}");
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                }
            }
            
            // Unget service
            bundleContext.ungetService(serviceRef);
            
        } catch (Exception e) {
            out.println("{\"error\": \"" + e.getMessage() + "\"}");
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            e.printStackTrace();
        }
    }
}