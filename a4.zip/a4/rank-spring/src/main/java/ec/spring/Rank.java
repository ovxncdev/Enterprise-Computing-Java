package ec.spring;

/**
 * Rank interface for getting grade and rank of scores.
 */
public interface Rank {
    /**
     * Get the letter grade for a given score.
     * Simply returns grade.getLetterGrade(score).
     * 
     * @param score the numerical score
     * @return the letter grade
     */
    String getGrade(int score);
    
    /**
     * Get the rank for a given score.
     * Returns the number of scores bigger than s plus 1.
     * Uses efficient data structure and algorithm.
     * 
     * @param s the score to rank
     * @return the rank (1-based, 1 is highest)
     */
    int getRank(int s);
}