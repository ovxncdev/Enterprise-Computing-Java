package ec.spring;

import java.util.Arrays;

/**
 * Implementation of Rank interface using binary search algorithm.
 */
public class RankImpl implements Rank {
    
    private String name;
    private Integer[] scores = {71, 71, 85, 70, 85, 99, 70, 79, 89, 83, 96, 85, 82, 84, 96, 
                                77, 89, 81, 71, 90, 89, 71, 99, 99, 84, 74, 90, 75, 73, 86};
    private int count;
    private Grade grade;
    
    // Sorted scores in descending order for efficient ranking
    private Integer[] sortedScores;
    
    /**
     * Default constructor.
     * Initializes by sorting scores in descending order.
     */
    public RankImpl() {
        initializeSortedScores();
    }
    
    /**
     * Initialize sorted scores array in descending order.
     */
    private void initializeSortedScores() {
        if (scores != null) {
            sortedScores = Arrays.copyOf(scores, scores.length);
            // Sort in descending order
            Arrays.sort(sortedScores, (a, b) -> b.compareTo(a));
            count = sortedScores.length;
        }
    }
    
    // Getters and Setters
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Integer[] getScores() {
        return scores;
    }
    
    public void setScores(Integer[] scores) {
        this.scores = scores;
        initializeSortedScores();
    }
    
    public int getCount() {
        return count;
    }
    
    public void setCount(int count) {
        this.count = count;
    }
    
    public Grade getGrade() {
        return grade;
    }
    
    public void setGrade(Grade grade) {
        this.grade = grade;
    }
    
    /**
     * Get the letter grade for a score.
     * Delegates to the injected Grade bean.
     */
    @Override
    public String getGrade(int score) {
        if (grade == null) {
            return "N/A";
        }
        return grade.getLetterGrade(score);
    }
    
    /**
     * Get the rank for a score using binary search.
     * Rank = number of scores bigger than s plus 1.
     * 
     * Algorithm:
     * - Uses binary search on sorted (descending) scores array
     * - Finds the position where score would be inserted
     * - Returns position + 1 (1-based ranking)
     * 
     * Time Complexity: O(log n)
     * 
     * @param s the score to rank
     * @return the rank (1 is highest)
     */
    @Override
    public int getRank(int s) {
        if (sortedScores == null || sortedScores.length == 0) {
            return 1;
        }
        
        // Binary search to find position in descending sorted array
        // We need to find how many scores are > s
        int left = 0;
        int right = sortedScores.length - 1;
        int position = sortedScores.length; // Default: all scores are bigger
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (sortedScores[mid] > s) {
                // Score at mid is bigger, search right half
                left = mid + 1;
            } else {
                // Score at mid is <= s, this could be our position
                position = mid;
                right = mid - 1;
            }
        }
        
        // Rank is position + 1 (1-based)
        return position + 1;
    }
}