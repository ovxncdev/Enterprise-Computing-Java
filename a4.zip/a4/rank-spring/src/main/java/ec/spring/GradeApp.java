package ec.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Spring main program to demonstrate Grade bean functionality.
 */
public class GradeApp {
    
    public static void main(String[] args) {
        // Create ApplicationContext container by reading GradeBeans.xml
        ApplicationContext context = new ClassPathXmlApplicationContext("GradeBeans.xml");
        
        System.out.println("=== Part 1: Default Grade Boundaries (66-100) ===");
        System.out.println();
        
        // Get Grade bean instance from container
        Grade gradeBean = (Grade) context.getBean("grade-bean");
        
        // Print letter grades for percentage grades from 66 to 100
        printGrades(gradeBean, 66, 100);
        
        System.out.println();
        System.out.println("=== Part 2: Extended Grade Boundaries (46-100) ===");
        System.out.println();
        
        // Get a new Grade instance from container
        Grade gradeBean2 = (Grade) context.getBean("grade-bean");
        
        // Reset properties with new datasets
        if (gradeBean2 instanceof GradeImpl) {
            GradeImpl impl = (GradeImpl) gradeBean2;
            
            // Set new grade boundaries
            int[] newBoundary = {100, 90, 85, 80, 77, 73, 70, 67, 63, 60, 57, 53, 50, 0};
            impl.setGradeBoundary(newBoundary);
            
            // Set new letter grades
            String[] newLetterGrade = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"};
            impl.setLetterGrade(newLetterGrade);
        }
        
        // Print letter grades for percentage grades from 46 to 100
        printGrades(gradeBean2, 46, 100);
        
        // Close the context
        ((ClassPathXmlApplicationContext) context).close();
    }
    
    /**
     * Print letter grades for a range of numerical grades.
     * Output format: 5 grades per line.
     * 
     * @param grade the Grade bean instance
     * @param start the starting numerical grade
     * @param end the ending numerical grade
     */
    private static void printGrades(Grade grade, int start, int end) {
        int count = 0;
        
        for (int i = start; i <= end; i++) {
            String letterGrade = grade.getLetterGrade(i);
            System.out.print(i + ":" + letterGrade + " ");
            count++;
            
            // Print newline after every 5 grades
            if (count % 5 == 0) {
                System.out.println();
            }
        }
        
        // Print final newline if needed
        if (count % 5 != 0) {
            System.out.println();
        }
    }
}