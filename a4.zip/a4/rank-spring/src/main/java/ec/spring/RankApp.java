package ec.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Arrays;
import java.util.TreeMap;

/**
 * Spring main program to demonstrate Rank bean functionality.
 */
public class RankApp {
    
    public static void main(String[] args) {
        // Create ApplicationContext container by reading RankBeans.xml
        ApplicationContext context = new ClassPathXmlApplicationContext("RankBeans.xml");
        
        // Get Rank bean instance from container
        Rank rankBean = (Rank) context.getBean("rank-bean");
        
        // Get the scores array from RankImpl to display all scores with ranks
        RankImpl rankImpl = (RankImpl) rankBean;
        Integer[] scores = rankImpl.getScores();
        
        // Create a sorted unique set of scores for display
        Integer[] uniqueScores = Arrays.stream(scores)
                .distinct()
                .sorted((a, b) -> b.compareTo(a))  // Sort descending
                .toArray(Integer[]::new);
        
        System.out.println("=== All Scores with Ranks and Grades ===");
        System.out.println();
        
        // Display all scores (including duplicates) with their ranks and grades
        Integer[] sortedAllScores = Arrays.copyOf(scores, scores.length);
        Arrays.sort(sortedAllScores, (a, b) -> b.compareTo(a));
        
        for (Integer score : sortedAllScores) {
            int rank = rankBean.getRank(score);
            String grade = rankBean.getGrade(score);
            System.out.println("score:" + score + ", rank:" + rank + ", grade:" + grade);
        }
        
        // Prediction example
        System.out.println("Prediction for score:76");
        int predictScore = 76;
        int predictRank = rankBean.getRank(predictScore);
        String predictGrade = rankBean.getGrade(predictScore);
        System.out.println("rank:" + predictRank + ", grade:" + predictGrade);
        
        // Close the context
        ((ClassPathXmlApplicationContext) context).close();
    }
}