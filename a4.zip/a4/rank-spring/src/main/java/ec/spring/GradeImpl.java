package ec.spring;

/**
 * Implementation of Grade interface using binary search algorithm.
 */
public class GradeImpl implements Grade {
    
    private String name;
    private int[] gradeBoundary = {100, 90, 85, 80, 77, 73, 70, 0};
    private String[] letterGrade = {"A+", "A", "A-", "B+", "B", "B-", "F"};
    private int count = 8;
    
    // Default constructor
    public GradeImpl() {
    }
    
    // Getters and Setters
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int[] getGradeBoundary() {
        return gradeBoundary;
    }
    
    public void setGradeBoundary(int[] gradeBoundary) {
        this.gradeBoundary = gradeBoundary;
        this.count = gradeBoundary.length;
    }
    
    public String[] getLetterGrade() {
        return letterGrade;
    }
    
    public void setLetterGrade(String[] letterGrade) {
        this.letterGrade = letterGrade;
    }
    
    public int getCount() {
        return count;
    }
    
    public void setCount(int count) {
        this.count = count;
    }
    
    /**
     * Get letter grade using binary search algorithm.
     * Finds the interval where the numerical grade falls.
     * 
     * @param numerical_grade the numerical grade (0-100)
     * @return the corresponding letter grade
     */
    @Override
    public String getLetterGrade(int numerical_grade) {
        // Handle edge cases
        if (numerical_grade < 0 || numerical_grade > 100) {
            return "Invalid";
        }
        
        // Binary search to find the correct grade interval
        int left = 0;
        int right = count - 1;
        int result = count - 1; // Default to last grade (F)
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            // Check if numerical_grade is in the current interval
            if (numerical_grade >= gradeBoundary[mid]) {
                result = mid;
                right = mid - 1; // Search left for higher boundary
            } else {
                left = mid + 1; // Search right for lower boundary
            }
        }
        
        // Return the corresponding letter grade
        // Note: gradeBoundary has one more element than letterGrade
        // Index mapping: boundary[i] corresponds to letterGrade[i]
        // But we need to handle the rightmost interval
        if (result == count - 1) {
            return letterGrade[letterGrade.length - 1];
        } else {
            return letterGrade[result];
        }
    }
}