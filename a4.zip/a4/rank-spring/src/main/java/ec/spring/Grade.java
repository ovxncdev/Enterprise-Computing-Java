package ec.spring;

/**
 * Grade interface for converting numerical grades to letter grades.
 */
public interface Grade {
    /**
     * Get the letter grade corresponding to the numerical grade.
     * 
     * @param numerical_grade the numerical grade (0-100)
     * @return the letter grade (e.g., "A+", "A", "B+", etc.)
     */
    String getLetterGrade(int numerical_grade);
}