package ec.osgi.consumer;

import ec.osgi.service.StatsOSGi;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

/**
 * OSGi Bundle Activator for Stats consumer.
 * Consumes the StatsOSGi service and prints statistics.
 */
public class Activator implements BundleActivator {
    
    @Override
    public void start(BundleContext context) throws Exception {
        System.out.println("Starting Stats OSGi Consumer Bundle...");
        
        // Get service reference
        ServiceReference<StatsOSGi> serviceRef = 
            context.getServiceReference(StatsOSGi.class);
        
        if (serviceRef != null) {
            // Get service
            StatsOSGi statsService = context.getService(serviceRef);
            
            if (statsService != null) {
                System.out.println("=== Stats OSGi Service Results ===");
                System.out.println("Count: " + statsService.getCount());
                System.out.println("Min:   " + statsService.getMin());
                System.out.println("Max:   " + statsService.getMax());
                System.out.println("Mean:  " + statsService.getMean());
                System.out.println("STD:   " + statsService.getSTD());
                System.out.println("===================================");
                
                // Unget service
                context.ungetService(serviceRef);
            } else {
                System.err.println("Failed to get StatsOSGi service!");
            }
        } else {
            System.err.println("StatsOSGi service reference not found!");
        }
        
        System.out.println("Stats OSGi Consumer Bundle started.");
    }
    
    @Override
    public void stop(BundleContext context) throws Exception {
        System.out.println("Stopping Stats OSGi Consumer Bundle...");
        System.out.println("Stats OSGi Consumer Bundle stopped.");
    }
}