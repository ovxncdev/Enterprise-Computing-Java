"""
House Price Prediction Microservice
Flask RESTful API using Weka Linear Regression model
"""

from flask import Flask, jsonify, request
import json
import os

app = Flask(__name__)

# Global variable to store the model
model = None

def load_model():
    """Load the Weka Linear Regression model from JSON file."""
    global model
    model_file = 'weka_regression.json'
    
    if not os.path.exists(model_file):
        print(f"Warning: {model_file} not found. Using default model.")
        # Default model structure
        model = {
            "model_type": "LinearRegression",
            "model_name": "weka_lr",
            "input_features": ["houseSize", "lotSize", "bedrooms", "granite", "bathroom"],
            "output_feature": "sellingPrice",
            "coefficients": [-26.9308, 6.3345, 44293.7603, 7140.6763, 43179.1997],
            "intercept": -21739.2962
        }
    else:
        with open(model_file, 'r') as f:
            model = json.load(f)
    
    print("Model loaded successfully:")
    print(f"  Type: {model.get('model_type')}")
    print(f"  Features: {model.get('input_features')}")
    print(f"  Coefficients: {model.get('coefficients')}")
    print(f"  Intercept: {model.get('intercept')}")

def predict_price(features):
    """
    Predict house price using linear regression.
    
    Args:
        features: List of 5 numeric values [houseSize, lotSize, bedrooms, granite, bathroom]
    
    Returns:
        Predicted price as float
    """
    if model is None:
        raise Exception("Model not loaded")
    
    if len(features) != 5:
        raise ValueError(f"Expected 5 features, got {len(features)}")
    
    # Linear regression: y = w1*x1 + w2*x2 + ... + wn*xn + intercept
    coefficients = model['coefficients']
    intercept = model['intercept']
    
    price = sum(coef * feat for coef, feat in zip(coefficients, features)) + intercept
    
    return price

@app.route('/')
def home():
    """Home endpoint with API information."""
    return jsonify({
        "service": "House Price Prediction Microservice",
        "version": "1.0.0",
        "model": model.get('model_name', 'unknown'),
        "endpoints": {
            "/": "API information",
            "/model": "Get model details (GET)",
            "/predict/<values>": "Predict price with comma-separated values (GET)",
            "/predict": "Predict price with JSON body (POST)"
        },
        "examples": {
            "GET": "curl http://localhost:8000/predict/3198,9669,5,1,1",
            "POST": 'curl -X POST -H "Content-Type: application/json" -d "{\\"attribute\\": \\"3198,9669,5,1,1\\"}" http://localhost:8000/predict'
        }
    })

@app.route('/model', methods=['GET'])
def get_model():
    """Return the model details in JSON format."""
    if model is None:
        return jsonify({"error": "Model not loaded"}), 500
    
    return jsonify(model)

@app.route('/predict/<path:values>', methods=['GET'])
def predict_get(values):
    """
    Predict house price using GET with path parameter.
    
    Example: /predict/3198,9669,5,1,1
    """
    try:
        # Parse comma-separated values
        features = [float(v.strip()) for v in values.split(',')]
        
        if len(features) != 5:
            return jsonify({
                "error": f"Expected 5 features, got {len(features)}",
                "required": "houseSize,lotSize,bedrooms,granite,bathroom"
            }), 400
        
        # Predict
        price = predict_price(features)
        
        return jsonify({
            "price": price,
            "features": {
                "houseSize": features[0],
                "lotSize": features[1],
                "bedrooms": features[2],
                "granite": features[3],
                "bathroom": features[4]
            }
        })
        
    except ValueError as e:
        return jsonify({"error": f"Invalid input: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/predict', methods=['POST'])
def predict_post():
    """
    Predict house price using POST with JSON body.
    
    Expected JSON:
    {
        "attribute": "3198,9669,5,1,1"
    }
    """
    try:
        # Get JSON data
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No JSON data provided"}), 400
        
        if 'attribute' not in data:
            return jsonify({"error": "Missing 'attribute' field in JSON"}), 400
        
        # Parse comma-separated values
        attribute_string = data['attribute']
        features = [float(v.strip()) for v in attribute_string.split(',')]
        
        if len(features) != 5:
            return jsonify({
                "error": f"Expected 5 features, got {len(features)}",
                "required": "houseSize,lotSize,bedrooms,granite,bathroom"
            }), 400
        
        # Predict
        price = predict_price(features)
        
        return jsonify({"price": price})
        
    except ValueError as e:
        return jsonify({"error": f"Invalid input: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "model_loaded": model is not None
    })

if __name__ == '__main__':
    # Load model on startup
    load_model()
    
    # Run Flask app
    # host='0.0.0.0' allows external connections (needed for Docker)
    app.run(host='0.0.0.0', port=8000, debug=True)