# LAB2 Report

Author: ADENIYI RIDWAN ADETUNJI

Date: 2025-09-27 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
# T1 Java Message Service (JMS) (lab practice)


### T1.1 Hand on helloworld-jms
 

Complete? Yes 

![helloworld-jms](images/helloworld-jms.png){width=90%}



### T1.2 JMS message queue programming
 

Complete? Yes 


![jmstopic](images/jmstopic.png){width=90%}



### T1.3 JMS topic programming
 

Complete? Yes 

![jmsmessageque](images/jmsmessageque.png){width=90%}



# T2 Message Driven Bean (MDB) (lab practice)


### T2.1 WildFly message within Eclipse
 

Complete? Yes 


![wildflymessagewithineclipse](images/wildflymessagewithineclipse.png){width=90%}


### T2.2 Hand on helloworld-mdb project
 

Complete? Yes 

![Handonhelloworld-mdbproject](images/Handonhelloworld-mdbproject.png){width=90%}



### T2.3 ec-ejb MDB components
 

Complete? Yes 


![ec-ejbMDBcomponents](images/ec-ejbMDBcomponents.png){width=90%}



### T2.4 JMS web clients
 

Complete? Yes 


![JMS-webclients](images/JMS-webclients.png){width=90%}



# T3 Database Connection (lab practice)


### T3.1 H2 database
 

Complete? Yes 

![threeone](images/threeone.png){width=90%}


### T3.2 MySQL database
 

Complete? Yes 


![threetwoxampp](images/threetwoxampp.png){width=90%}


### T3.3 JDBC client programming
 

Complete? Yes 

![lab2dbtest](images/lab2dbtest.png){width=90%}



# T4 JPA and Hibernate (lab practice)


### T4.1 Hand on JPA example
 

Complete? Yes 


![jpaexample](images/jpaexample.png){width=90%}



### T4.2 Hand on ec-jpa project
 

Complete? Yes 


![jpalittletwo](images/jpalittletwo.png){width=90%}




# T5 Entity Beans (lab practice)


### T5.1 Entity Beans with embedded H2
 

Complete? Yes 


![greeterentitybean](images/greeterentitybean.png){width=90%}



### T5.2 Entity Beans with standalone H2
 

Complete? Yes 


![adduserh](images/adduserh.png){width=90%}
![selectuserh](images/selectuserh.png){width=90%}

### T5.3 Entity Beans with MySQL
 

Complete? Yes 


![EbMysqladd](images/EbMysqladd.png){width=90%}
![EbMysqlselect](images/EbMysqlselect.png){width=90%}

### T5.4 ec-ejb entity components
 

Complete? Yes 

![last](images/last.png){width=90%}




**References**

1. CP630OC lab2
2. Add your references if you used any. 
