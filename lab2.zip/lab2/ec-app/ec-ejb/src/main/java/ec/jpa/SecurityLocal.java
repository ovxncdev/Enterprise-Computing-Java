package ec.jpa;

import javax.ejb.Local;

@Local
public interface SecurityLocal {
    Boolean validate(String user);
}
