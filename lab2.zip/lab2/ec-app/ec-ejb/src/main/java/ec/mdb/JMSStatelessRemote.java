package ec.mdb;

import javax.ejb.Remote;

@Remote
public interface JMSStatelessRemote {
    boolean sendMessageToQueue(String message);
    boolean sendMessageToTopic(String message);
}
