package ec.mdb;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.jms.Topic;

@Stateless(name = "JMSStateless")
@Remote(JMSStatelessRemote.class)
@Local(JMSStatelessLocal.class)
public class JMSStateless implements JMSStatelessRemote, JMSStatelessLocal {

    @Inject
    JMSContext context;

    @Resource(lookup = "java:/queue/test")
    private Queue queue;

    @Resource(lookup = "java:/topic/test")
    private Topic topic;

    @Override
    public boolean sendMessageToQueue(String mstr) {
        context.createProducer().send(queue, mstr);
        return true;
    }

    @Override
    public boolean sendMessageToTopic(String mstr) {
        context.createProducer().send(topic, mstr);
        return true;
    }
}
