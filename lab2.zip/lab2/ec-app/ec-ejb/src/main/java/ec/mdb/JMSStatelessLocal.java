package ec.mdb;

import javax.ejb.Local;

@Local
public interface JMSStatelessLocal {
    boolean sendMessageToQueue(String message);
    boolean sendMessageToTopic(String message);
}
