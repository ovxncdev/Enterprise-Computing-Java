package ec.jms;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ec.mdb.JMSStatelessRemote;

@WebServlet("/SBJMSWebServlet")
public class SBJMSWebServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Explicit cross-deployment lookup into the ec-ejb module:
    @EJB(lookup = "java:global/ec-ejb/JMSStateless!ec.mdb.JMSStatelessRemote")
    private JMSStatelessRemote jms;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            String msg = req.getParameter("msg");
            if (msg == null || msg.isEmpty()) msg = "hello";

            boolean q = jms.sendMessageToQueue("WEB: " + msg);
            boolean t = jms.sendMessageToTopic("WEB: " + msg);

            out.println("Sent to Queue: " + q + "<br>");
            out.println("Sent to Topic: " + t + "<br>");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
