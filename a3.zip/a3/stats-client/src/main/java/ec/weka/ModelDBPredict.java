package ec.weka;

import ec.asgmt.db.DBUtil;
import weka.classifiers.Classifier;
import weka.classifiers.functions.LinearRegression;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;

public class ModelDBPredict {

    public static void main(String[] args) throws Exception {
        String table = null;
        String name  = null;
        String query = null;
        String schema = "house"; // future-proof: more schemas can be added later

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-table": table = next(args, ++i); break;
                case "-name":  name  = next(args, ++i); break;
                case "-query": query = next(args, ++i); break;
                case "-schema": schema = next(args, ++i); break;
                default: /* ignore */ ;
            }
        }

        if (table == null || name == null || query == null) {
            System.err.println("Usage: java -cp target/stats-client.jar ec.weka.ModelDBPredict " +
                               "-table <ecmodel> -name <model-name> -query \"v1,v2,...\" " +
                               "[-schema house]");
            System.exit(1);
        }

        // 1) Load serialized model bytes from DB
        byte[] bytes;
        String modelClass;
        try (Connection cx = DBUtil.getConnection()) {
            String sql = "SELECT object, classname FROM " + table + " WHERE name = ? " +
                         "ORDER BY date DESC LIMIT 1";
            try (PreparedStatement ps = cx.prepareStatement(sql)) {
                ps.setString(1, name);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalStateException("No model named '" + name + "' in table '" + table + "'");
                    }
                    bytes = rs.getBytes(1);
                    modelClass = rs.getString(2);
                }
            }
        }

        // 2) Deserialize to Weka Classifier
        Classifier cls;
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();
            if (!(obj instanceof Classifier)) {
                throw new IllegalStateException("Stored object is not a Weka Classifier. Class=" + obj.getClass());
            }
            cls = (Classifier) obj;
        }

        if (!(cls instanceof LinearRegression)) {
            // You can relax this if you plan to support more models later
            throw new IllegalStateException("Expected LinearRegression, got " + cls.getClass().getName());
        }

        // 3) Build an Instances header matching the training ARFF
        Instances header = buildHeader(schema);        // class index set inside
        Instance inst = makeInstanceFromQuery(query, header);

        // 4) Predict
        double pred = cls.classifyInstance(inst);

        System.out.println("=== Prediction from DB model ===");
        System.out.println("Table     : " + table);
        System.out.println("Name      : " + name);
        System.out.println("Class     : " + modelClass);
        System.out.println("Query     : " + query);
        System.out.println("Predicted : " + pred);
    }

    private static String next(String[] a, int i) {
        return (i < a.length) ? a[i] : null;
    }

    /** Build a header that matches the house*.arff files:
     *  houseSize, lotSize, bedrooms, granite, bathroom, sellingPrice(class) */
    private static Instances buildHeader(String schema) {
        if (!"house".equalsIgnoreCase(schema)) {
            throw new IllegalArgumentException("Unsupported -schema: " + schema + " (only 'house' is implemented)");
        }

        ArrayList<Attribute> atts = new ArrayList<>();
        atts.add(new Attribute("houseSize"));
        atts.add(new Attribute("lotSize"));
        atts.add(new Attribute("bedrooms"));
        atts.add(new Attribute("granite"));
        atts.add(new Attribute("bathroom"));
        atts.add(new Attribute("sellingPrice")); // class

        Instances ds = new Instances("house", atts, 1);
        ds.setClassIndex(ds.numAttributes() - 1);
        return ds;
    }

    /** Parse CSV query and create a DenseInstance bound to the header.
     *  If the user passes 6 numbers (last is dummy class), we ignore the last one. */
    private static Instance makeInstanceFromQuery(String csv, Instances header) {
        String[] parts = Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toArray(String[]::new);

        // expect 5 feature values; ignore a 6th dummy if present
        int needed = header.classIndex(); // number of non-class attributes == 5
        if (parts.length < needed) {
            throw new IllegalArgumentException("Expected at least " + needed +
                    " numeric values for features. Got " + parts.length + " : " + csv);
        }

        double[] vals = new double[header.numAttributes()];
        for (int i = 0; i < needed; i++) {
            vals[i] = Double.parseDouble(parts[i]);
        }
        // class is unknown -> set to missing
        vals[header.classIndex()] = weka.core.Utils.missingValue();

        Instance inst = new DenseInstance(1.0, vals);
        inst.setDataset(header);
        return inst;
    }
}
