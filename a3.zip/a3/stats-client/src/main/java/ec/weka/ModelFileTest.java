package ec.weka;

import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.Evaluation;
import weka.core.SerializationHelper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;

public class ModelFileTest {

    public static void main(String[] args) throws Exception {
        String modelFile = null;
        String dataFile = null;
        String testFile = null;
        String outFile = null;

        // Parse CLI args
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-modelfile":
                    modelFile = args[++i];
                    break;
                case "-datafile":
                    dataFile = args[++i]; // training (for header + Evaluation ctor)
                    break;
                case "-testfile":
                    testFile = args[++i];
                    break;
                case "-outfile":
                    outFile = args[++i];
                    break;
            }
        }

        if (modelFile == null || dataFile == null || testFile == null) {
            System.err.println("Usage:");
            System.err.println("  java -cp target/stats-client.jar ec.weka.ModelFileTest "
                    + "-modelfile <model.bin> -datafile <train.arff> -testfile <test.arff> -outfile <result.txt>");
            System.exit(1);
        }

        // 1) Load datasets
        Instances train = DataSource.read(dataFile);
        if (train.classIndex() < 0) train.setClassIndex(train.numAttributes() - 1);

        Instances test = DataSource.read(testFile);
        if (test.classIndex() < 0) test.setClassIndex(test.numAttributes() - 1);

        // 2) Load model
        Object obj = SerializationHelper.read(modelFile);
        if (!(obj instanceof LinearRegression)) {
            throw new IllegalArgumentException("Provided model is not a Weka LinearRegression model: " + modelFile);
        }
        LinearRegression model = (LinearRegression) obj;

        // 3) Evaluate
        Evaluation eval = new Evaluation(train);
        eval.evaluateModel(model, test);

        // 4) Build output
        String report = buildReport(eval, model, test);

        // 5) Print + save
        System.out.println(report);
        if (outFile != null) {
            writeText(outFile, report);
            System.out.println("Results written to: " + outFile);
        }
    }

    private static String buildReport(Evaluation eval, LinearRegression model, Instances test) throws Exception {
        StringBuilder sb = new StringBuilder();
        DecimalFormat df = new DecimalFormat("#.######");

        sb.append("=== Evaluation on test set ===\n\n");
        sb.append(eval.toSummaryString("Summary", false)).append("\n");
        sb.append("Correlation Coefficient : ").append(df.format(eval.correlationCoefficient())).append("\n");
        sb.append("Mean Absolute Error     : ").append(df.format(eval.meanAbsoluteError())).append("\n");
        sb.append("Root Mean Squared Error : ").append(df.format(eval.rootMeanSquaredError())).append("\n");
        sb.append("Relative Absolute Error : ").append(df.format(eval.relativeAbsoluteError())).append("%\n");
        sb.append("Relative RMSE           : ").append(df.format(eval.rootRelativeSquaredError())).append("%\n\n");

        sb.append("=== Per-instance predictions ===\n");
        sb.append(String.format("%-8s %-18s %-18s%n", "Index", "Actual", "Predicted"));
        for (int i = 0; i < test.numInstances(); i++) {
            double actual = test.instance(i).classValue();
            double pred = model.classifyInstance(test.instance(i));
            sb.append(String.format("%-8d %-18s %-18s%n", i, df.format(actual), df.format(pred)));
        }

        return sb.toString();
    }

    private static void writeText(String path, String content) throws IOException {
        Files.createDirectories(Paths.get(path).toAbsolutePath().getParent());
        Files.write(Paths.get(path), content.getBytes());
    }
}
