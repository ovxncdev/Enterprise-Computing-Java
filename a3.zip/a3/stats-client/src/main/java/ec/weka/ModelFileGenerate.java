package ec.weka;

import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.functions.LinearRegression;
import weka.core.SelectedTag;
import weka.core.SerializationHelper;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
import java.io.FileWriter;
import java.io.StringWriter;

public class ModelFileGenerate {
    
    public static void main(String[] args) throws Exception {
        String dataFile = null;
        String modelFile = null;
        String jsonModelFile = null;
        
        // Parse command line arguments
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-datafile")) {
                dataFile = args[++i];
            } else if (args[i].equals("-modelfile")) {
                modelFile = args[++i];
            } else if (args[i].equals("-jsonmodelfile")) {
                jsonModelFile = args[++i];
            }
        }
        
        if (dataFile == null) {
            System.err.println("Usage: java -cp target/stats-client.jar ec.weka.ModelFileGenerate -datafile <file> [-modelfile <file>] [-jsonmodelfile <file>]");
            System.exit(1);
        }
        
        // Load training data
        Instances trainingDataSet = DataSource.read(dataFile);
        trainingDataSet.setClassIndex(trainingDataSet.numAttributes() - 1);
        
        // Build linear regression model
        LinearRegression cls = new LinearRegression();
        SelectedTag method = new SelectedTag(LinearRegression.SELECTION_NONE, LinearRegression.TAGS_SELECTION);
        cls.setAttributeSelectionMethod(method);
        cls.buildClassifier(trainingDataSet);
        
        System.out.println("Linear Regression Model:");
        System.out.println(cls);
        
        // Save binary model if specified
        if (modelFile != null) {
            SerializationHelper.write(modelFile, cls);
            System.out.println("Model saved to: " + modelFile);
        }
        
        // Save JSON model if specified
        if (jsonModelFile != null) {
            saveModelAsJSON(cls, trainingDataSet, jsonModelFile);
            System.out.println("JSON model saved to: " + jsonModelFile);
        }
    }
    
    private static void saveModelAsJSON(LinearRegression model, Instances data, String filename) throws Exception {
        double[] coefficients = model.coefficients();
        
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder()
            .add("model_type", "LinearRegression")
            .add("model_name", "weka_lr")
            .add("output_feature", data.classAttribute().name());
        
        // Add input features
        JsonArrayBuilder inputFeatures = Json.createArrayBuilder();
        for (int i = 0; i < data.numAttributes() - 1; i++) {
            inputFeatures.add(data.attribute(i).name());
        }
        jsonBuilder.add("input_features", inputFeatures);
        
        // Add coefficients (excluding intercept)
        JsonArrayBuilder coeffArray = Json.createArrayBuilder();
        for (int i = 0; i < coefficients.length - 1; i++) {
            coeffArray.add(coefficients[i]);
        }
        jsonBuilder.add("coefficients", coeffArray);
        
        // Add intercept (last coefficient)
        jsonBuilder.add("intercept", coefficients[coefficients.length - 1]);
        
        JsonObject jsonModel = jsonBuilder.build();
        
        // Write to file
        try (FileWriter fw = new FileWriter(filename)) {
            StringWriter sw = new StringWriter();
            try (JsonWriter writer = Json.createWriter(sw)) {
                writer.writeObject(jsonModel);
            }
            fw.write(sw.toString());
        }
    }
}