package ec.weka;

import ec.asgmt.db.DBUtil;
import weka.classifiers.functions.LinearRegression;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.converters.ConverterUtils.DataSource;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Train a Weka LinearRegression model from an ARFF file and save it to the ecmodel table.
 * 
 * Usage:
 *   java -cp target/stats-client.jar ec.weka.ModelDBSave 
 *        -datafile data/house.arff 
 *        -name weka-lr 
 *        -table ecmodel
 */
public class ModelDBSave {

    public static void main(String[] args) throws Exception {
        String dataFile = null;
        String name = "weka-lr";  // default
        String table = "ecmodel"; // default

        // Parse arguments
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-datafile": dataFile = next(args, ++i); break;
                case "-name":     name     = next(args, ++i); break;
                case "-table":    table    = next(args, ++i); break;
                default: /* ignore unknown args */ ;
            }
        }

        if (dataFile == null) {
            System.err.println("Usage: java -cp target/stats-client.jar ec.weka.ModelDBSave " +
                             "-datafile <file> [-name weka-lr] [-table ecmodel]");
            System.exit(1);
        }

        System.out.println("=== Training and Saving Weka Model ===");
        System.out.println("Data file : " + dataFile);
        System.out.println("Model name: " + name);
        System.out.println("Table     : " + table);

        // 1) Load training data
        Instances trainingDataSet = DataSource.read(dataFile);
        trainingDataSet.setClassIndex(trainingDataSet.numAttributes() - 1);
        System.out.println("Loaded " + trainingDataSet.numInstances() + " instances with " + 
                          trainingDataSet.numAttributes() + " attributes");

        // 2) Build LinearRegression model
        LinearRegression cls = new LinearRegression();
        SelectedTag method = new SelectedTag(LinearRegression.SELECTION_NONE, 
                                            LinearRegression.TAGS_SELECTION);
        cls.setAttributeSelectionMethod(method);
        cls.buildClassifier(trainingDataSet);

        System.out.println("\nTrained Linear Regression Model:");
        System.out.println(cls);

        // 3) Serialize model to byte array
        byte[] modelBytes;
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(cls);
            oos.flush();
            modelBytes = baos.toByteArray();
        }

        String className = cls.getClass().getName();
        System.out.println("\nSerialized model size: " + modelBytes.length + " bytes");
        System.out.println("Model class: " + className);

        // 4) Save to database (DELETE old, INSERT new)
        try (Connection conn = DBUtil.getConnection()) {
            conn.setAutoCommit(false);

            try {
                // Delete any existing model with this name
                String deleteSql = "DELETE FROM " + table + " WHERE name = ?";
                try (PreparedStatement ps = conn.prepareStatement(deleteSql)) {
                    ps.setString(1, name);
                    int deleted = ps.executeUpdate();
                    if (deleted > 0) {
                        System.out.println("\nDeleted " + deleted + " existing model(s) named '" + name + "'");
                    }
                }

                // Insert new model
                String insertSql = "INSERT INTO " + table + 
                                  " (name, object, classname, date) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
                    ps.setString(1, name);
                    ps.setBytes(2, modelBytes);
                    ps.setString(3, className);
                    ps.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
                    
                    int inserted = ps.executeUpdate();
                    System.out.println("Inserted " + inserted + " new model record");
                }

                conn.commit();
                System.out.println("\n✓ SUCCESS: Model '" + name + "' saved to table '" + table + "'");

            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        }
    }

    private static String next(String[] args, int i) {
        return (i < args.length) ? args[i] : null;
    }
}