package ec.weka;

import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.functions.LinearRegression;
import weka.core.SerializationHelper;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class ModelFilePredict {

    public static void main(String[] args) throws Exception {
        String modelBin = null;
        String modelJson = null;
        String predictFile = null;
        String outFile = null;

        // Parse args
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-modelfile":
                    modelBin = args[++i];
                    break;
                case "-jsonmodelfile":
                    modelJson = args[++i];
                    break;
                case "-predictfile":
                    predictFile = args[++i];
                    break;
                case "-outfile":
                    outFile = args[++i];
                    break;
                default:
                    break;
            }
        }

        if (predictFile == null || (modelBin == null && modelJson == null) || (modelBin != null && modelJson != null)) {
            System.err.println("Usage (choose exactly ONE model option):");
            System.err.println("  java -cp target/stats-client.jar ec.weka.ModelFilePredict "
                    + "-modelfile <model.bin> -predictfile <predict.arff> [-outfile result.txt]");
            System.err.println("  OR");
            System.err.println("  java -cp target/stats-client.jar ec.weka.ModelFilePredict "
                    + "-jsonmodelfile <model.json> -predictfile <predict.arff> [-outfile result.txt]");
            System.exit(1);
        }

        // Load prediction instances
        Instances predict = DataSource.read(predictFile);
        if (predict.classIndex() < 0) {
            predict.setClassIndex(predict.numAttributes() - 1);
        }

        String report;
        if (modelBin != null) {
            report = predictWithBinaryModel(modelBin, predict);
        } else {
            report = predictWithJsonModel(modelJson, predict);
        }

        // Print and optionally write
        System.out.println(report);
        if (outFile != null) {
            writeText(outFile, report);
            System.out.println("Results written to: " + outFile);
        }
    }

    // ---------- Binary (.bin) model ----------
    private static String predictWithBinaryModel(String modelFile, Instances predict) throws Exception {
        Object obj = SerializationHelper.read(modelFile);
        if (!(obj instanceof LinearRegression)) {
            throw new IllegalArgumentException("Provided model is not a Weka LinearRegression model: " + modelFile);
        }
        LinearRegression model = (LinearRegression) obj;

        DecimalFormat df = new DecimalFormat("#.##############");
        StringBuilder sb = new StringBuilder();
        sb.append("=== Predictions using binary model ===\n");
        sb.append("Model file: ").append(modelFile).append("\n");
        sb.append(String.format("%-8s %-18s%n", "Index", "Predicted"));

        for (int i = 0; i < predict.numInstances(); i++) {
            Instance inst = predict.instance(i);
            double pred = model.classifyInstance(inst);
            sb.append(String.format("%-8d %-18s%n", i, df.format(pred)));
        }
        return sb.toString();
    }

    // ---------- JSON model (tolerant reader) ----------
    private static String predictWithJsonModel(String jsonModelFile, Instances predict) throws Exception {
        JsonObject m = readJson(jsonModelFile);

        JsonArray features = m.getJsonArray("input_features");
        JsonArray coeffs   = m.getJsonArray("coefficients");
        if (features == null || coeffs == null) {
            throw new IllegalArgumentException("JSON model missing 'input_features' or 'coefficients'.");
        }

        // Intercept is required and stored separately
        double intercept = m.getJsonNumber("intercept").doubleValue();

        int nFeat = features.size();
        int cSize = coeffs.size();

        // Tolerate mismatches: if more coeffs than features, use the first nFeat
        // If fewer, fail fast (can't safely infer)
        if (cSize < nFeat) {
            throw new IllegalArgumentException(
                "JSON model has fewer coefficients (" + cSize + ") than input_features (" + nFeat + ").");
        } else if (cSize > nFeat) {
            // Often happens if an older exporter included an extra slot (e.g., class or intercept).
            // We'll log a note and truncate.
            System.err.println(
                "Note: coefficients count (" + cSize + ") > input_features (" + nFeat + "). " +
                "Using the first " + nFeat + " coefficients.");
        }

        // Map feature name -> attribute index in predict Instances
        Map<String,Integer> featIndex = new HashMap<>();
        for (int i = 0; i < nFeat; i++) {
            String fname = features.getString(i);
            int idx = predict.attribute(fname) != null ? predict.attribute(fname).index() : -1;
            if (idx < 0) {
                throw new IllegalArgumentException("Predict ARFF is missing feature: " + fname);
            }
            featIndex.put(fname, idx);
        }

        DecimalFormat df = new DecimalFormat("#.##############");
        StringBuilder sb = new StringBuilder();
        sb.append("=== Predictions using JSON model ===\n");
        sb.append("JSON model file: ").append(jsonModelFile).append("\n");
        sb.append(String.format("%-8s %-18s%n", "Index", "Predicted"));

        // y = intercept + sum(coeff[i] * x[i]) with robust handling of NaN coeffs
        for (int r = 0; r < predict.numInstances(); r++) {
            Instance inst = predict.instance(r);
            double yhat = intercept;
            for (int i = 0; i < nFeat; i++) {
                String fname = features.getString(i);
                double coeff = coeffs.getJsonNumber(i).doubleValue();
                if (Double.isNaN(coeff)) coeff = 0.0; // unused attribute
                int attIndex = featIndex.get(fname);
                double x = inst.value(attIndex);
                yhat += coeff * x;
            }
            sb.append(String.format("%-8d %-18s%n", r, df.format(yhat)));
        }
        return sb.toString();
    }

    private static JsonObject readJson(String path) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(Paths.get(path));
             JsonReader reader = Json.createReader(br)) {
            return reader.readObject();
        }
    }

    private static void writeText(String path, String content) throws IOException {
        if (Paths.get(path).getParent() != null) {
            Files.createDirectories(Paths.get(path).toAbsolutePath().getParent());
        }
        Files.write(Paths.get(path), content.getBytes());
    }
}
