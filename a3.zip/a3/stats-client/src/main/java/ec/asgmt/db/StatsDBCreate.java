package ec.asgmt.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class StatsDBCreate {

    public static void main(String[] args) throws Exception {
        // Ensure database exists, then create tables
        String dbUrl  = DBUtil.url();
        String dbUser = DBUtil.user();
        String dbPass = DBUtil.pass();

        String dbName = extractDbName(dbUrl);
        String sysUrl = stripDbName(dbUrl); // connect to server without schema to CREATE DATABASE

        // 1) CREATE DATABASE IF NOT EXISTS <dbName>
        try (Connection sys = java.sql.DriverManager.getConnection(sysUrl, dbUser, dbPass);
             Statement st = sys.createStatement()) {
            st.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + dbName + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            System.out.println("Database ensured: " + dbName);
        }

        // 2) CREATE TABLES (id auto-increment, constraints, types)
        try (Connection cx = DBUtil.getConnection();
             Statement st = cx.createStatement()) {

            String createEcUser =
                    "CREATE TABLE IF NOT EXISTS ecuser (" +
                    "  id INT NOT NULL AUTO_INCREMENT," +
                    "  name VARCHAR(100) NOT NULL UNIQUE," +
                    "  password CHAR(32) NOT NULL," +         // MD5 hex
                    "  role TINYINT NOT NULL," +              // 1=admin, 2=dev, 3=user
                    "  PRIMARY KEY (id)" +
                    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            String createEcModel =
                    "CREATE TABLE IF NOT EXISTS ecmodel (" +
                    "  id INT NOT NULL AUTO_INCREMENT," +
                    "  name VARCHAR(100) NOT NULL UNIQUE," +
                    "  object MEDIUMBLOB NOT NULL," +         // serialized model bytes
                    "  classname VARCHAR(255) NOT NULL," +
                    "  date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
                    "  PRIMARY KEY (id)" +
                    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            st.executeUpdate(createEcUser);
            st.executeUpdate(createEcModel);
            System.out.println("Tables ensured: ecuser, ecmodel");
        }

        System.out.println("StatsDBCreate completed.");
    }

    private static String extractDbName(String url) {
        // expects ...://host:port/dbName?params
        int slash = url.lastIndexOf('/');
        if (slash < 0) throw new IllegalArgumentException("DB name not found in URL: " + url);
        String tail = url.substring(slash + 1);
        int q = tail.indexOf('?');
        return (q >= 0) ? tail.substring(0, q) : tail;
    }

    private static String stripDbName(String url) {
        // turn jdbc:mysql://host:port/db?x=y into jdbc:mysql://host:port/?x=y (or just root URL)
        int slash = url.lastIndexOf('/');
        if (slash < 0) return url;
        // keep protocol + host:port, drop the db name
        String base = url.substring(0, slash + 1);
        // if there were params after db, keep them
        String tail = url.substring(slash + 1);
        int q = tail.indexOf('?');
        return (q >= 0) ? base + tail.substring(q) : base;
    }
}
