package ec.asgmt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DbBootstrap {
    // Connect as root with EMPTY password (adjust if yours differs)
    private static final String ADMIN_URL  =
        "jdbc:mysql://localhost:3306/?useSSL=false&serverTimezone=UTC";
    private static final String ADMIN_USER = "root";
    private static final String ADMIN_PASS = ""; // <— change if your root has a password

    public static void main(String[] args) throws Exception {
        try (Connection c = DriverManager.getConnection(ADMIN_URL, ADMIN_USER, ADMIN_PASS);
             Statement  s = c.createStatement()) {

            // 1) Ensure DB
            s.executeUpdate("CREATE DATABASE IF NOT EXISTS cp630 CHARACTER SET utf8mb4");

            // 2) Try “old” grant syntax that both creates user and grants (works on MariaDB/old MySQL)
            try {
                s.executeUpdate("GRANT ALL PRIVILEGES ON cp630.* TO 'cp630'@'localhost' IDENTIFIED BY 'cp630'");
            } catch (Exception e) {
                // 3) Fallback for newer servers: explicit create user + grant
                try {
                    s.executeUpdate("CREATE USER IF NOT EXISTS 'cp630'@'localhost' IDENTIFIED BY 'cp630'");
                } catch (Exception ignore) { /* user may already exist */ }
                s.executeUpdate("GRANT ALL PRIVILEGES ON cp630.* TO 'cp630'@'localhost'");
            }
            s.execute("FLUSH PRIVILEGES");

            System.out.println("Bootstrap done: database cp630 + user cp630/cp630 ready.");
        }
    }
}
