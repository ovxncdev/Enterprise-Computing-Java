package ec.stats.ws;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

public class StatsWSClient {
    
    public static void main(String[] args) {
        try {
            // WSDL URL of the deployed SOAP service
            URL wsdlUrl = new URL("http://localhost:8080/stats-ws/StatsWSImpl?wsdl");
            
            // Qualified name of the service
            QName serviceName = new QName("http://ws.asgmt.ec/", "StatsWSService");
            
            // Create service
            Service service = Service.create(wsdlUrl, serviceName);
            
            // Get the port (interface)
            QName portName = new QName("http://ws.asgmt.ec/", "StatsWSPort");
            StatsWS statsWS = service.getPort(portName, StatsWS.class);
            
            // Call the web service methods and display results
            System.out.println("=== Statistics Summary Information ===");
            System.out.println("Count: " + statsWS.getCount());
            System.out.println("Minimum: " + statsWS.getMin());
            System.out.println("Maximum: " + statsWS.getMax());
            System.out.println("Mean: " + statsWS.getMean());
            System.out.println("Standard Deviation: " + statsWS.getSTD());
            System.out.println("=====================================");
            
        } catch (Exception e) {
            System.err.println("Error calling SOAP Web Service: " + e.getMessage());
            e.printStackTrace();
        }
    }
}