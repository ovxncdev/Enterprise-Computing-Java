package ec.asgmt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

public class StatsDBSelect {

    // Self-contained connection helper (no DbUtil dependency)
    private static Connection getConnection() throws Exception {
        // allow override via env vars if you need
        String url  = System.getenv().getOrDefault("CP630_DB_URL",
                "jdbc:mysql://localhost:3306/cp630?useSSL=false&serverTimezone=UTC");
        String user = System.getenv().getOrDefault("CP630_DB_USER", "root");
        String pass = System.getenv().getOrDefault("CP630_DB_PASS", "");
        return DriverManager.getConnection(url, user, pass);
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> p = parseArgs(args);
        String table = req(p, "table");
        String name  = req(p, "name");

        try (Connection cn = getConnection()) {
            if ("ecuser".equalsIgnoreCase(table)) {
                selectUser(cn, name);
            } else if ("ecmodel".equalsIgnoreCase(table)) {
                selectModel(cn, name);
            } else {
                throw new IllegalArgumentException("Unsupported table: " + table + " (use ecuser | ecmodel)");
            }
        }
    }

    private static void selectUser(Connection cn, String name) throws Exception {
        String sql = "SELECT id, name, role FROM ecuser WHERE name = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int id   = rs.getInt("id");
                    String nm = rs.getString("name");
                    int role = rs.getInt("role");
                    System.out.printf("ecuser: id=%d, name=%s, role=%d%n", id, nm, role);
                } else {
                    System.out.println("ecuser: no record found for name=" + name);
                }
            }
        }
    }

    private static void selectModel(Connection cn, String name) throws Exception {
        String sql = "SELECT id, name, classname, LENGTH(object) AS bytes, date FROM ecmodel WHERE name = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String nm = rs.getString("name");
                    String clazz = rs.getString("classname");
                    long bytes = rs.getLong("bytes");
                    java.sql.Timestamp ts = rs.getTimestamp("date");
                    System.out.printf("ecmodel: id=%d, name=%s, class=%s, bytes=%d, date=%s%n",
                            id, nm, clazz, bytes, ts);
                } else {
                    System.out.println("ecmodel: no record found for name=" + name);
                }
            }
        }
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i < args.length; i++) {
            if (args[i].startsWith("-")) {
                String key = args[i].replaceFirst("^-+", "");
                String val = (i + 1 < args.length && !args[i + 1].startsWith("-")) ? args[++i] : "true";
                m.put(key, val);
            }
        }
        return m;
    }

    private static String req(Map<String, String> m, String key) {
        String v = m.get(key);
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing required arg: -" + key);
        }
        return v.trim();
    }
}
