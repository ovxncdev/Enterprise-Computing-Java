package ec.stats.ws;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService(targetNamespace = "http://ws.asgmt.ec/")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public interface StatsWS {
    
    @WebMethod
    @WebResult(name = "count")
    Long getCount();
    
    @WebMethod
    @WebResult(name = "minimum")
    Double getMin();
    
    @WebMethod
    @WebResult(name = "maximum")
    Double getMax();
    
    @WebMethod
    @WebResult(name = "mean")
    Double getMean();
    
    @WebMethod
    @WebResult(name = "standardDeviation")
    Double getSTD();
}