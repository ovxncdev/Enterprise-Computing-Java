package ec.asgmt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DBUtil {

    // Configure via JVM props or env vars if you like:
    //  -DSTATS_DB_URL=jdbc:mysql://localhost:3306/cp630?... 
    //  -DSTATS_DB_USER=root
    //  -DSTATS_DB_PASS=yourpass
    private static final String URL  =
            System.getProperty("STATS_DB_URL",
            System.getenv().getOrDefault("STATS_DB_URL",
            "jdbc:mysql://localhost:3306/cp630?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC"));

    private static final String USER =
            System.getProperty("STATS_DB_USER",
            System.getenv().getOrDefault("STATS_DB_USER", "root"));

    private static final String PASS =
            System.getProperty("STATS_DB_PASS",
            System.getenv().getOrDefault("STATS_DB_PASS", ""));

    private DBUtil() {}

    public static String url()  { return URL; }
    public static String user() { return USER; }
    public static String pass() { return PASS; }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void closeQuietly(AutoCloseable c) {
        try { if (c != null) c.close(); } catch (Exception ignored) {}
    }
}
