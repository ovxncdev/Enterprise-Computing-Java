JobID: cp630oc-a3
Name: Adeniyi Ridwan Adetunji
ID: 245852450

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A3

Q1 Web service project
Q1.1 [20/20/*] SOAP WS                                 
Q1.2 [10/10/*] SOAP WS clients                         
Q1.3 [20/20/*] RESTful Web service                     

Q2 Linear regression for EC
Q2.1 [20/20/*] LR Model Generation by Weka API         
Q2.2 [10/10/*] LR Model in Database                    
Q2.3 [10/10/*] LR Session Bean Component               
Q2.4 [10/10/*] LR Web Component                        

Q3 Batch test
Q3.1 [0/0/*]  Create test output                     

Total: [100/100/*]

