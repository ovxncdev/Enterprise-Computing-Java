**Date**
24/6/2018

**Author**
Lubna Rahal

**Title**
data directory contents.

1. .model files:
trained models files on the two datasets.


2. tae.arff, car.arff:
twd datasets used to train the models.


3. tae_unlabeled.arff, car_unlabeled.arff:
two test data collections to test the performance of the models.

4. tae_test.arff, car_test.arff:
real classes values of unlabeled data, to compare real classes values with those predicted by models.

5. tae_labeled.arff, car_labeled.arff:
the predicted results by the model

5. ta_instance.arff, car_instance.arff:
two instances that can be used to predict their class using the Predict.jar