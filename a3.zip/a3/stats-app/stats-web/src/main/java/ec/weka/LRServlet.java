package ec.weka;

import ec.asgmt.lr.LRStatelessLocal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/predict")
public class LRServlet extends HttpServlet {
    
    @EJB
    private LRStatelessLocal lrStateless;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Get parameters from query string
            String name = request.getParameter("name");
            String query = request.getParameter("query");
            
            // Validate parameters
            if (name == null || query == null) {
                out.println("<html><body>");
                out.println("<h2>Error: Missing Parameters</h2>");
                out.println("<p>Required parameters: name and query</p>");
                out.println("<p>Example: /predict?name=weka-lr&query=3198,9669,5,1,1,0</p>");
                out.println("</body></html>");
                return;
            }
            
            // Parse the query string to display values
            String[] dataValues = query.split(",");
            
            // Validate we have at least 5 values (the 6th is optional/dummy)
            if (dataValues.length < 5) {
                out.println("<html><body>");
                out.println("<h2>Error: Invalid Query Format</h2>");
                out.println("<p>Expected at least 5 comma-separated values: houseSize,lotSize,bedrooms,granite,bathroom[,dummy]</p>");
                out.println("<p>Received: " + dataValues.length + " values</p>");
                out.println("</body></html>");
                return;
            }
            
            // Call the EJB to make prediction
            // Pass the full query string - the EJB handles parsing
            double prediction = lrStateless.prediction(query);
            
            // Parse values for display
            double houseSize = Double.parseDouble(dataValues[0].trim());
            double lotSize = Double.parseDouble(dataValues[1].trim());
            double bedrooms = Double.parseDouble(dataValues[2].trim());
            double granite = Double.parseDouble(dataValues[3].trim());
            double bathroom = Double.parseDouble(dataValues[4].trim());
            
            // Output result
            out.println("<html><head><title>House Price Prediction</title></head><body>");
            out.println("<h2>House Price Prediction Result</h2>");
            out.println("<h3>Model: " + name + "</h3>");
            out.println("<table border='1' cellpadding='5' cellspacing='0'>");
            out.println("<tr><th>Attribute</th><th>Value</th></tr>");
            out.println("<tr><td>House Size (sq ft)</td><td>" + houseSize + "</td></tr>");
            out.println("<tr><td>Lot Size (sq ft)</td><td>" + lotSize + "</td></tr>");
            out.println("<tr><td>Bedrooms</td><td>" + bedrooms + "</td></tr>");
            out.println("<tr><td>Granite (1=yes, 0=no)</td><td>" + granite + "</td></tr>");
            out.println("<tr><td>Bathroom</td><td>" + bathroom + "</td></tr>");
            out.println("<tr><td><strong>Predicted Price</strong></td><td><strong>$" + String.format("%.2f", prediction) + "</strong></td></tr>");
            out.println("</table>");
            out.println("<br><a href='index-lr.html'>Make Another Prediction</a>");
            out.println("</body></html>");
            
        } catch (NumberFormatException e) {
            out.println("<html><body>");
            out.println("<h2>Error: Invalid Number Format</h2>");
            out.println("<p>All query values must be numeric</p>");
            out.println("<p>Error: " + e.getMessage() + "</p>");
            out.println("</body></html>");
        } catch (IllegalArgumentException e) {
            out.println("<html><body>");
            out.println("<h2>Error: Invalid Argument</h2>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("</body></html>");
        } catch (Exception e) {
            out.println("<html><body>");
            out.println("<h2>Error Processing Request</h2>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            out.close();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}