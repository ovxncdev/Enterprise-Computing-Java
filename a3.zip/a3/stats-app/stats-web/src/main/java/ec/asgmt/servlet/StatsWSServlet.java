package ec.asgmt.servlet;

import ec.asgmt.ws.client.StatsWS;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;

@WebServlet("/statsws")
public class StatsWSServlet extends HttpServlet {
    
    private static final String WSDL_URL = "http://localhost:8080/stats-ws/StatsWSImpl?wsdl";
    private static final String NAMESPACE = "http://ws.asgmt.ec/";
    private static final String SERVICE_NAME = "StatsWSService";
    private static final String PORT_NAME = "StatsWSPort";
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Create HTML response
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Statistics Summary - SOAP WS Client</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; margin: 40px; }");
            out.println("h1 { color: #333; }");
            out.println("table { border-collapse: collapse; width: 50%; margin-top: 20px; }");
            out.println("th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }");
            out.println("th { background-color: #4CAF50; color: white; }");
            out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Statistics Summary Information</h1>");
            out.println("<p>Data retrieved from SOAP Web Service</p>");
            
            // Call SOAP Web Service
            URL wsdlUrl = new URL(WSDL_URL);
            QName serviceName = new QName(NAMESPACE, SERVICE_NAME);
            Service service = Service.create(wsdlUrl, serviceName);
            
            QName portName = new QName(NAMESPACE, PORT_NAME);
            StatsWS statsWS = service.getPort(portName, StatsWS.class);
            
            // Get statistics data
            Long count = statsWS.getCount();
            Double min = statsWS.getMin();
            Double max = statsWS.getMax();
            Double mean = statsWS.getMean();
            Double std = statsWS.getSTD();
            
            // Display results in HTML table
            out.println("<table>");
            out.println("<tr><th>Statistic</th><th>Value</th></tr>");
            out.println("<tr><td>Count</td><td>" + (count != null ? count : "N/A") + "</td></tr>");
            out.println("<tr><td>Minimum</td><td>" + (min != null ? String.format("%.2f", min) : "N/A") + "</td></tr>");
            out.println("<tr><td>Maximum</td><td>" + (max != null ? String.format("%.2f", max) : "N/A") + "</td></tr>");
            out.println("<tr><td>Mean</td><td>" + (mean != null ? String.format("%.2f", mean) : "N/A") + "</td></tr>");
            out.println("<tr><td>Standard Deviation</td><td>" + (std != null ? String.format("%.2f", std) : "N/A") + "</td></tr>");
            out.println("</table>");
            
            out.println("<p style='margin-top: 20px; color: green;'>Successfully retrieved data from SOAP service!</p>");
            
        } catch (Exception e) {
            out.println("<h2 style='color: red;'>Error accessing SOAP Web Service</h2>");
            out.println("<p>Error: " + e.getMessage() + "</p>");
            out.println("<pre>");
            e.printStackTrace(out);
            out.println("</pre>");
        } finally {
            out.println("</body>");
            out.println("</html>");
            out.close();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}