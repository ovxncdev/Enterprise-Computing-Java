package ec.asgmt.user;

import ec.asgmt.sb.UserDao;           // interface lives in ec.asgmt.sb
import ec.asgmt.entity.User;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@WebServlet(urlPatterns = {"/user"})
public class StatsUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private UserDao userDao;

    private static String md5Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String action = req.getParameter("action"); // add | login | list
        if (action == null) {
            out.println("Usage:");
            out.println("  /user?action=add&name=...&password=...&role=1|2|3");
            out.println("  /user?action=login&name=...&password=...");
            out.println("  /user?action=list");
            return;
        }

        try {
            switch (action.toLowerCase()) {
                case "add": {
                    String name = req.getParameter("name");
                    String password = req.getParameter("password");
                    String roleStr = req.getParameter("role");
                    if (name == null || password == null || roleStr == null) {
                        resp.setStatus(400);
                        out.println("Missing params. Need name, password, role");
                        return;
                    }
                    int role;
                    try {
                        role = Integer.parseInt(roleStr);
                    } catch (NumberFormatException nfe) {
                        resp.setStatus(400);
                        out.println("Invalid role. Use 1 (admin), 2 (developer), 3 (user).");
                        return;
                    }
                    User u = new User();
                    u.setName(name.trim());
                    u.setPassword(md5Hex(password));
                    u.setRole(role);
                    userDao.addUser(u);
                    out.println("Added user: " + u.getName() + " (role=" + role + ")");
                    break;
                }
                case "login": {
                    String name = req.getParameter("name");
                    String password = req.getParameter("password");
                    if (name == null || password == null) {
                        resp.setStatus(400);
                        out.println("Missing params. Need name, password");
                        return;
                    }
                    User u = userDao.getUser(name.trim(), md5Hex(password));
                    if (u != null) {
                        out.println("Login OK: id=" + u.getId() + " name=" + u.getName() + " role=" + u.getRole());
                    } else {
                        resp.setStatus(401);
                        out.println("Invalid credentials");
                    }
                    break;
                }
                case "list": {
                    for (User u : userDao.getAllUser()) {
                        out.println(u.getId() + " | " + u.getName() + " | role=" + u.getRole());
                    }
                    break;
                }
                default:
                    resp.setStatus(400);
                    out.println("Unknown action: " + action);
            }
        } catch (Exception e) {
            resp.setStatus(500);
            e.printStackTrace(out);
        }
    }
}
