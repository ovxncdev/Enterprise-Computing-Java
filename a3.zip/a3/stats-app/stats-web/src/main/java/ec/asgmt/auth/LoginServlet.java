package ec.asgmt.auth;

import ec.asgmt.entity.User;
import ec.asgmt.sb.UserDao;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private UserDao userDao; // injected from stats-ejb

    private static String md5Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // direct GETs back to the login page
        resp.sendRedirect(req.getContextPath() + "/login.html");
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String name = req.getParameter("name");
        String password = req.getParameter("password");

        if (name == null || password == null) {
            resp.setStatus(400);
            out.println("<h3>Missing username or password</h3>");
            out.println("<a href='login.html'>Back</a>");
            return;
        }

        try {
            String enc = md5Hex(password);
            User u = userDao.getUser(name.trim(), enc);

            if (u == null) {
                resp.setStatus(401);
                out.println("<h3>Invalid credentials</h3>");
                out.println("<a href='login.html'>Try again</a>");
                return;
            }

            int role = u.getRole();
            out.println("<html><body>");
            out.printf("<h2>Welcome, %s (role=%d)</h2>%n", u.getName(), role);

            switch (role) {
                case 1: // Admin
                    out.println("<h3>Admin Console</h3>");
                    out.println("<h4>Add user</h4>");
                    out.println("<form action='user' method='get'>");
                    out.println("<input type='hidden' name='action' value='add'/>");
                    out.println("Name: <input name='name'/> ");
                    out.println("Password: <input name='password'/> ");
                    out.println("Role (1/2/3): <input name='role' value='3'/> ");
                    out.println("<button type='submit'>Add</button>");
                    out.println("</form>");

                    out.println("<h4>List all users</h4>");
                    out.println("<a href='user?action=list' target='_blank'>/user?action=list</a>");

                    out.println("<h4>Check a user (login)</h4>");
                    out.println("<form action='user' method='get' target='_blank'>");
                    out.println("<input type='hidden' name='action' value='login'/>");
                    out.println("Name: <input name='name'/> ");
                    out.println("Password: <input name='password'/> ");
                    out.println("<button type='submit'>Check</button>");
                    out.println("</form>");
                    break;

                case 2: // Developer
                    out.println("<h3>Developer Console</h3>");
                    out.println("<p>Save current StatsSummary via JMS queue:</p>");
                    out.println("<form action='producer' method='get' target='_blank'>");
                    out.println("<input type='hidden' name='message' value='save'/>");
                    out.println("<button type='submit'>Send 'save' to queue</button>");
                    out.println("</form>");

                    out.println("<p>Save with custom name (sends <code>save:name</code>):</p>");
                    out.println("<form action='producer' method='get' target='_blank'>");
                    out.println("Name: <input name='message' value='save:stats'/> ");
                    out.println("<button type='submit'>Save named model</button>");
                    out.println("</form>");

                    out.println("<p>Inspect models:</p>");
                    out.println("<a href='model?action=list' target='_blank'>/model?action=list</a>");
                    break;

                case 3: // General user
                    out.println("<h3>User Console</h3>");
                    out.println("<form action='get' method='get' target='_blank'>");
                    out.println("<select name='value'>");
                    out.println("<option value='count'>count</option>");
                    out.println("<option value='min'>min</option>");
                    out.println("<option value='max'>max</option>");
                    out.println("<option value='mean'>mean</option>");
                    out.println("<option value='std'>std</option>");
                    out.println("<option value='summary'>summary</option>");
                    out.println("</select> ");
                    out.println("<button type='submit'>Query</button>");
                    out.println("</form>");
                    break;

                default:
                    out.println("<p>Unknown role.</p>");
            }

            out.println("<hr/><a href='login.html'>Log out</a>");
            out.println("</body></html>");
        } catch (Exception e) {
            resp.setStatus(500);
            out.println("<pre>");
            e.printStackTrace(out);
            out.println("</pre>");
        }
    }
}
