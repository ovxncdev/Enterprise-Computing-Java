package ec.asgmt.jms;

import java.io.IOException;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.Topic;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/publisher")
public class StatsJMSPublisherServlet extends HttpServlet {

    @Inject
    private JMSContext jms;

    @Resource(lookup = "java:/jms/topic/StatsTopic")
    private Topic statsTopic;

    private Topic resolveTopic() {
        if (statsTopic != null) return statsTopic;
        try {
            InitialContext ic = new InitialContext();
            Object t = ic.lookup("java:/jms/topic/StatsTopic");
            if (t instanceof Topic) return (Topic) t;
            t = ic.lookup("java:jboss/exported/jms/topic/StatsTopic");
            if (t instanceof Topic) return (Topic) t;
        } catch (NamingException ignored) {}
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String msg = req.getParameter("message");
        try {
            Double.parseDouble(msg);
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().println("Expected ?message=<double>, got: " + msg);
            return;
        }

        Topic t = resolveTopic();
        if (t == null) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().println("Topic not found via JNDI: tried java:/jms/topic/StatsTopic and java:jboss/exported/jms/topic/StatsTopic");
            return;
        }

        jms.createProducer().send(t, msg);
        resp.getWriter().println("Published to topic StatsTopic: " + msg);
    }
}
