package ec.asgmt.jms;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.naming.InitialContext;

@WebServlet("/sbpublisher")
public class StatsJMSStatelessPublisherServlet extends HttpServlet {

    @EJB
    private StatsJMSStatelessLocal stats;

    private StatsJMSStatelessLocal resolveBean() {
        if (stats != null) return stats;
        try {
            InitialContext ic = new InitialContext();
            Object o;
            o = ic.lookup("java:global/stats-ear/stats-ejb/StatsJMSStateless!ec.asgmt.jms.StatsJMSStatelessLocal");
            if (o instanceof StatsJMSStatelessLocal) return (StatsJMSStatelessLocal)o;
            o = ic.lookup("java:app/stats-ejb/StatsJMSStateless!ec.asgmt.jms.StatsJMSStatelessLocal");
            if (o instanceof StatsJMSStatelessLocal) return (StatsJMSStatelessLocal)o;
            o = ic.lookup("java:module/StatsJMSStateless!ec.asgmt.jms.StatsJMSStatelessLocal");
            if (o instanceof StatsJMSStatelessLocal) return (StatsJMSStatelessLocal)o;
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
        try {
            String msg = req.getParameter("message");
            StatsJMSStatelessLocal bean = resolveBean();
            if (bean == null) {
                resp.setStatus(500);
                resp.getWriter().println("EJB lookup failed: StatsJMSStatelessLocal is null");
                return;
            }
            bean.publish(msg);
            resp.getWriter().println("Published to topic: " + msg);
        } catch (Exception e) {
            try {
                resp.setStatus(500);
                resp.getWriter().println("Error: " + e);
            } catch (Exception ignore) {}
        }
    }
}
