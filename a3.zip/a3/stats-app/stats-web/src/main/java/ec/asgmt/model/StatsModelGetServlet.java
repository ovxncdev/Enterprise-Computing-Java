package ec.asgmt.model;

import ec.asgmt.entity.Model;
import ec.asgmt.sb.ModelDao;
import ec.asgmt.StatsSummary;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.*;

@WebServlet(urlPatterns = {"/modelget"})
public class StatsModelGetServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private ModelDao modelDao;

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String modelName = paramOr(req, "modelname", "name"); // accept modelname OR name
        String query = req.getParameter("query");             // count|min|max|mean|std|summary

        if (modelName == null || modelName.trim().isEmpty()) {
            resp.setStatus(400);
            out.println("Missing param: modelname");
            return;
        }
        if (query == null || query.trim().isEmpty()) {
            resp.setStatus(400);
            out.println("Missing param: query (count|min|max|mean|std|summary)");
            return;
        }
        modelName = modelName.trim();
        query = query.trim().toLowerCase();

        try {
            Model row = modelDao.getModel(modelName);
            if (row == null) {
                resp.setStatus(404);
                out.println("No model named: " + modelName);
                return;
            }
            byte[] bytes = row.getObject();
            if (bytes == null || bytes.length == 0) {
                resp.setStatus(500);
                out.println("Model row has no payload.");
                return;
            }

            Object obj;
            try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
                obj = ois.readObject();
            }

            if (!(obj instanceof StatsSummary)) {
                resp.setStatus(415);
                out.println("Stored object is not StatsSummary: " + obj.getClass().getName());
                return;
            }
            StatsSummary s = (StatsSummary) obj;

            switch (query) {
                case "count":   out.println(s.getCount()); break;
                case "min":     out.println(s.getMin());   break;
                case "max":     out.println(s.getMax());   break;
                case "mean":    out.println(s.getMean());  break;
                case "std":     out.println(s.getSTD());   break;
                case "summary": out.print(s.toString());   break;
                default:
                    resp.setStatus(400);
                    out.println("Unknown query: " + query + " (use count|min|max|mean|std|summary)");
            }
        } catch (ClassNotFoundException cnf) {
            resp.setStatus(500);
            out.println("Class not found while deserializing: " + cnf.getMessage());
        } catch (Exception e) {
            resp.setStatus(500);
            e.printStackTrace(out);
        }
    }

    private static String paramOr(HttpServletRequest req, String a, String b) {
        String v = req.getParameter(a);
        return (v != null && !v.isEmpty()) ? v : req.getParameter(b);
    }
}
