package ec.asgmt.model;

import ec.asgmt.StatsSummary;
import ec.asgmt.entity.Model;
import ec.asgmt.sb.ModelDao;
import ec.asgmt.sb.StatsStatelessLocal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/modelsave"})
public class StatsModelSaveServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB private StatsStatelessLocal stats; // read count/min/max/mean/std
    @EJB private ModelDao modelDao;         // persist the model row

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String modelName = req.getParameter("modelname");
        if (modelName == null || modelName.trim().isEmpty()) {
            modelName = "stats";
        }
        modelName = modelName.trim();

        try {
            // Snapshot current stats
            StatsSummary summary = new StatsSummary();
            summary.setCount(stats.getCount());
            summary.setMin(stats.getMin());
            summary.setMax(stats.getMax());
            summary.setMean(stats.getMean());
            summary.setSTD(stats.getSTD());

            // Fill entity & persist using the DAO’s saveModel(..) as the spec asks
            Model m = new Model();
            m.setName(modelName);
            m.setClassname(StatsSummary.class.getName());
            m.setObject(serialize(summary));

            modelDao.saveModel(m);

            out.println("Saved model '" + modelName + "' (class=" + m.getClassname() + ").");
            out.println("--- snapshot ---");
            out.println("count: " + summary.getCount());
            out.println("min:   " + summary.getMin());
            out.println("max:   " + summary.getMax());
            out.println("mean:  " + summary.getMean());
            out.println("std:   " + summary.getSTD());
        } catch (Exception e) {
            resp.setStatus(500);
            e.printStackTrace(out);
        }
    }

    private static byte[] serialize(Object obj) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(bos)) {
            oos.writeObject(obj);
            oos.flush();
            return bos.toByteArray();
        } catch (Exception ex) {
            throw new RuntimeException("Failed to serialize model", ex);
        }
    }
}
