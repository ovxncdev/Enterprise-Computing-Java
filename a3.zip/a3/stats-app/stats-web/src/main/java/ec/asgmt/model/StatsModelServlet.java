package ec.asgmt.model;

import ec.asgmt.sb.ModelDao;
import ec.asgmt.entity.Model;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.*;
import java.util.List;

@WebServlet(urlPatterns = {"/model"})
public class StatsModelServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private ModelDao modelDao;

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/plain;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String action = req.getParameter("action"); // list | get | delete
        if (action == null) {
            out.println("Usage:");
            out.println("  /model?action=list");
            out.println("  /model?action=get&name=stats");
            out.println("  /model?action=delete&name=stats");
            return;
        }

        try {
            switch (action.toLowerCase()) {
                case "list": {
                    List<Model> rows = modelDao.list();
                    if (rows.isEmpty()) {
                        out.println("No models found.");
                    } else {
                        for (Model m : rows) {
                            out.printf("%d | %s | class=%s | bytes=%d | date=%s%n",
                                    m.getId(), m.getName(), m.getClassname(),
                                    m.getObject() == null ? 0 : m.getObject().length,
                                    String.valueOf(m.getDate()));
                        }
                    }
                    break;
                }
                case "get": {
                    String name = req.getParameter("name");
                    if (name == null || name.isEmpty()) {
                        resp.setStatus(400);
                        out.println("Missing param: name");
                        return;
                    }
                    Model m = modelDao.get(name);
                    if (m == null) {
                        out.println("No model named: " + name);
                        return;
                    }
                    out.printf("id=%d name=%s class=%s bytes=%d date=%s%n",
                            m.getId(), m.getName(), m.getClassname(),
                            m.getObject() == null ? 0 : m.getObject().length,
                            String.valueOf(m.getDate()));

                    // Best-effort deserialize (may fail if class not visible to web module)
                    if (m.getObject() != null) {
                        try (ObjectInputStream ois =
                                     new ObjectInputStream(new ByteArrayInputStream(m.getObject()))) {
                            Object obj = ois.readObject();
                            out.println("--- deserialized object ---");
                            out.println(String.valueOf(obj));
                        } catch (ClassNotFoundException cnf) {
                            out.println("Note: Could not deserialize object (class not visible to web module): " + cnf.getMessage());
                        } catch (Exception ex) {
                            out.println("Error deserializing object: " + ex.getMessage());
                        }
                    }
                    break;
                }
                case "delete": {
                    String name = req.getParameter("name");
                    if (name == null || name.isEmpty()) {
                        resp.setStatus(400);
                        out.println("Missing param: name");
                        return;
                    }
                    boolean ok = modelDao.delete(name);
                    out.println(ok ? ("Deleted: " + name) : ("No such model: " + name));
                    break;
                }
                default:
                    resp.setStatus(400);
                    out.println("Unknown action: " + action);
            }
        } catch (Exception e) {
            resp.setStatus(500);
            e.printStackTrace(out);
        }
    }
}
