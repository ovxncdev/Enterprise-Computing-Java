package ec.asgmt.rs;

import ec.asgmt.sb.StatsStatelessLocal;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * RESTful Web Service for statistics summary information
 * Returns statistics data in JSON format
 */
@Path("/")
@RequestScoped
public class StatsRS {
    
    @EJB
    private StatsStatelessLocal statsStateless;
    
    /**
     * Get all statistics in one JSON response
     * URL: /stats-rs/rest/all
     */
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllStats() {
        JsonObject json = Json.createObjectBuilder()
            .add("count", statsStateless != null ? statsStateless.getCount() : 0)
            .add("min", statsStateless != null ? statsStateless.getMin() : 0.0)
            .add("max", statsStateless != null ? statsStateless.getMax() : 0.0)
            .add("mean", statsStateless != null ? statsStateless.getMean() : 0.0)
            .add("std", statsStateless != null ? statsStateless.getSTD() : 0.0)
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Get count
     * URL: /stats-rs/rest/count
     */
    @GET
    @Path("/count")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCount() {
        int count = statsStateless != null ? statsStateless.getCount() : 0;
        JsonObject json = Json.createObjectBuilder()
            .add("count", count)
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Get minimum value
     * URL: /stats-rs/rest/min
     */
    @GET
    @Path("/min")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMin() {
        double min = statsStateless != null ? statsStateless.getMin() : 0.0;
        JsonObject json = Json.createObjectBuilder()
            .add("min", String.valueOf(min))
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Get maximum value
     * URL: /stats-rs/rest/max
     */
    @GET
    @Path("/max")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMax() {
        double max = statsStateless != null ? statsStateless.getMax() : 0.0;
        JsonObject json = Json.createObjectBuilder()
            .add("max", String.valueOf(max))
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Get mean value
     * URL: /stats-rs/rest/mean
     */
    @GET
    @Path("/mean")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMean() {
        double mean = statsStateless != null ? statsStateless.getMean() : 0.0;
        JsonObject json = Json.createObjectBuilder()
            .add("mean", String.valueOf(mean))
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Get standard deviation
     * URL: /stats-rs/rest/std
     */
    @GET
    @Path("/std")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSTD() {
        double std = statsStateless != null ? statsStateless.getSTD() : 0.0;
        JsonObject json = Json.createObjectBuilder()
            .add("std", String.valueOf(std))
            .build();
        
        return Response.ok(json).build();
    }
    
    /**
     * Health check endpoint
     * URL: /stats-rs/rest/health
     */
    @GET
    @Path("/health")
    @Produces(MediaType.APPLICATION_JSON)
    public Response health() {
        JsonObject json = Json.createObjectBuilder()
            .add("status", "UP")
            .add("service", "Stats RESTful Web Service")
            .build();
        
        return Response.ok(json).build();
    }
}