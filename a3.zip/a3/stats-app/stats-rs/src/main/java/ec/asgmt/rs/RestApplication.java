package ec.asgmt.rs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * JAX-RS Application configuration
 * This sets the base path for all REST services to /rest
 */
@ApplicationPath("/rest")
public class RestApplication extends Application {
    // No need to override any methods for basic configuration
}