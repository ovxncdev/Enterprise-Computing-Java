package ec.asgmt.ws;

import javax.ejb.EJB;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import ec.asgmt.sb.StatsStatelessLocal;

/**
 * SOAP Web Service implementation for statistics summary information
 * This class implements the StatsWS interface and delegates calls to StatsStateless EJB
 */
@WebService(
    serviceName = "StatsWSService",
    portName = "StatsWSPort",
    name = "StatsWS",
    endpointInterface = "ec.asgmt.ws.StatsWS",
    targetNamespace = "http://ws.asgmt.ec/"
)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public class StatsWSImpl implements StatsWS {
    
    /**
     * Injected StatsStateless EJB for accessing statistics data
     */
    @EJB
    private StatsStatelessLocal statsStateless;
    
    /**
     * Get the count of statistics entries
     * @return the total count
     */
    @Override
    public Long getCount() {
        if (statsStateless != null) {
            return Long.valueOf(statsStateless.getCount());
        }
        return 0L;
    }
    
    /**
     * Get the minimum value from statistics
     * @return the minimum value
     */
    @Override
    public Double getMin() {
        if (statsStateless != null) {
            return Double.valueOf(statsStateless.getMin());
        }
        return null;
    }
    
    /**
     * Get the maximum value from statistics
     * @return the maximum value
     */
    @Override
    public Double getMax() {
        if (statsStateless != null) {
            return Double.valueOf(statsStateless.getMax());
        }
        return null;
    }
    
    /**
     * Get the mean (average) value from statistics
     * @return the mean value
     */
    @Override
    public Double getMean() {
        if (statsStateless != null) {
            return Double.valueOf(statsStateless.getMean());
        }
        return null;
    }
    
    /**
     * Get the standard deviation from statistics
     * @return the standard deviation
     */
    @Override
    public Double getSTD() {
        if (statsStateless != null) {
            return Double.valueOf(statsStateless.getSTD());
        }
        return null;
    }
}