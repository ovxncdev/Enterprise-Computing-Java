package ec.asgmt.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.WebResult;
import javax.jws.soap.SOAPBinding;

/**
 * SOAP Web Service interface for statistics summary information
 */
@WebService(name = "StatsWS", targetNamespace = "http://ws.asgmt.ec/")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public interface StatsWS {
    
    /**
     * Get the count of statistics entries
     * @return the total count
     */
    @WebMethod(operationName = "getCount")
    @WebResult(name = "count")
    Long getCount();
    
    /**
     * Get the minimum value from statistics
     * @return the minimum value
     */
    @WebMethod(operationName = "getMin")
    @WebResult(name = "minimum")
    Double getMin();
    
    /**
     * Get the maximum value from statistics
     * @return the maximum value
     */
    @WebMethod(operationName = "getMax")
    @WebResult(name = "maximum")
    Double getMax();
    
    /**
     * Get the mean (average) value from statistics
     * @return the mean value
     */
    @WebMethod(operationName = "getMean")
    @WebResult(name = "mean")
    Double getMean();
    
    /**
     * Get the standard deviation from statistics
     * @return the standard deviation
     */
    @WebMethod(operationName = "getSTD")
    @WebResult(name = "standardDeviation")
    Double getSTD();
}