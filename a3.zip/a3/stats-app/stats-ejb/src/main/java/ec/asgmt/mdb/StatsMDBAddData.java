package ec.asgmt.mdb;

import ec.asgmt.sb.StatsDataLocal; // keep using your existing local interface

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * MDB that consumes numbers from java:/jms/topic/StatsTopic and adds them to the stats list.
 */
@MessageDriven(
    name = "StatsMDBAddData",
    activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationType",   propertyValue = "javax.jms.Topic"),
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/jms/topic/StatsTopic"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode",   propertyValue = "Auto-acknowledge")
    }
)
public class StatsMDBAddData implements MessageListener {

    @EJB
    private StatsDataLocal stats; // your existing SB that exposes add(double)

    @Override
    public void onMessage(Message message) {
        try {
            if (!(message instanceof TextMessage)) {
                System.out.println("[StatsMDBAddData] Ignored non-text message: " + message);
                return;
            }

            final String raw = ((TextMessage) message).getText();
            if (raw == null) {
                System.out.println("[StatsMDBAddData] Empty text message.");
                return;
            }

            final String trimmed = raw.trim();
            if (trimmed.isEmpty()) {
                System.out.println("[StatsMDBAddData] Blank text message.");
                return;
            }

            // Accept plain numbers (e.g., "10", "20.75"); ignore anything else
            final double val = Double.parseDouble(trimmed);
            stats.add(val);
            System.out.println("[StatsMDBAddData] Added value: " + val);
        } catch (NumberFormatException nfe) {
            System.out.println("[StatsMDBAddData] Non-numeric payload ignored.");
        } catch (Exception e) {
            System.err.println("[StatsMDBAddData] Error handling message: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
