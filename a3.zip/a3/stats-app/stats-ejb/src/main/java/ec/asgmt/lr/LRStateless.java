package ec.asgmt.lr;

import ec.asgmt.entity.Model;
import weka.classifiers.Classifier;
import weka.classifiers.functions.LinearRegression;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;

@Stateless
public class LRStateless implements LRStatelessLocal {

    private static final String DEFAULT_MODEL_NAME = "weka-lr";

    @PersistenceContext(unitName = "primary")
    private EntityManager em;

    @Override
    public double prediction(String argument) {
        // 1) Load last model row by name
        Model m = latestModelByName(DEFAULT_MODEL_NAME);
        if (m == null || m.getObject() == null) {
            throw new IllegalStateException("No model bytes found for name '" + DEFAULT_MODEL_NAME + "'");
        }

        // 2) Deserialize to Weka Classifier
        Classifier cls = deserialize(m.getObject());
        if (!(cls instanceof LinearRegression)) {
            throw new IllegalStateException("Expected LinearRegression, got: " + cls.getClass().getName());
        }

        // 3) Build header compatible with house*.arff
        Instances header = buildHouseHeader();

        // 4) Parse CSV -> Instance
        Instance inst = parseCsvToInstance(argument, header);

        // 5) Predict
        try {
            return cls.classifyInstance(inst);
        } catch (Exception e) {
            throw new RuntimeException("Prediction failed", e);
        }
    }

    private Model latestModelByName(String name) {
        // NOTE: if your Model entity uses different property names, tell me and paste it so I can match it.
        TypedQuery<Model> q = em.createQuery(
                "SELECT m FROM Model m WHERE m.name = :name ORDER BY m.date DESC",
                Model.class
        );
        q.setParameter("name", name);
        q.setMaxResults(1);
        return q.getResultList().stream().findFirst().orElse(null);
    }

    private Classifier deserialize(byte[] bytes) {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();
            if (!(obj instanceof Classifier)) {
                throw new IllegalStateException("Stored object is not a Weka Classifier: " + obj.getClass());
            }
            return (Classifier) obj;
        } catch (Exception e) {
            throw new RuntimeException("Could not deserialize model bytes", e);
        }
    }

    /** Build: houseSize, lotSize, bedrooms, granite, bathroom, sellingPrice(class) */
    private Instances buildHouseHeader() {
        ArrayList<Attribute> atts = new ArrayList<>();
        atts.add(new Attribute("houseSize"));
        atts.add(new Attribute("lotSize"));
        atts.add(new Attribute("bedrooms"));
        atts.add(new Attribute("granite"));
        atts.add(new Attribute("bathroom"));
        atts.add(new Attribute("sellingPrice")); // class
        Instances ds = new Instances("house", atts, 1);
        ds.setClassIndex(ds.numAttributes() - 1);
        return ds;
    }

    private Instance parseCsvToInstance(String csv, Instances header) {
        String[] parts = Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toArray(String[]::new);

        int features = header.classIndex(); // five features
        if (parts.length < features) {
            throw new IllegalArgumentException("Need at least " + features +
                    " numbers (houseSize,lotSize,bedrooms,granite,bathroom). Got: " + parts.length);
        }
        double[] vals = new double[header.numAttributes()];
        for (int i = 0; i < features; i++) {
            vals[i] = Double.parseDouble(parts[i]);
        }
        vals[header.classIndex()] = Utils.missingValue(); // class unknown

        Instance inst = new DenseInstance(1.0, vals);
        inst.setDataset(header);
        return inst;
    }
}
