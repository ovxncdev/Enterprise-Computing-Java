package ec.asgmt.lr;

import javax.ejb.Local;

/**
 * Predict using the latest stored Weka LR model (default name: "weka-lr").
 * argument is a CSV string: houseSize,lotSize,bedrooms,granite,bathroom[,dummy]
 */
@Local
public interface LRStatelessLocal {

    /**
     * Predict sellingPrice from a CSV of feature values.
     * @param argument CSV like "3198,9669,5,1,1,0"
     * @return predicted value (double)
     */
    double prediction(String argument);
}
