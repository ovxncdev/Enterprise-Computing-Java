package ec.asgmt.sb;

import ec.asgmt.entity.Model;
import java.util.List;
import javax.ejb.Local;

@Local
public interface ModelDao {

    // ===== Assignment-required signatures =====
    /**
     * Save or update a model entity (by its name).
     * NOTE: Default throws until Step 3 implementation is added.
     */
    default void saveModel(Model model) {
        throw new UnsupportedOperationException("saveModel(Model) not implemented yet (Step 3 will add it).");
    }

    /**
     * Get a model entity by name.
     * Default delegates to existing get(name) so current callers keep working.
     */
    default Model getModel(String modelname) {
        return get(modelname);
    }

    // ===== Existing methods you already use (keep!) =====
    /** Insert or update a model row by name, serializing the object */
    void save(String name, Object modelObject);

    /** Fetch a model row by name (raw row; caller can deserialize bytes). */
    Model get(String name);

    /** Delete by name; return true if a row was deleted. */
    boolean delete(String name);

    /** List all rows. */
    List<Model> list();
}
