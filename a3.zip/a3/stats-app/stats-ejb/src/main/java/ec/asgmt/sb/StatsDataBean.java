package ec.asgmt.sb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;

@Singleton
@LocalBean
public class StatsDataBean implements StatsDataLocal {
    private final List<Double> data = Collections.synchronizedList(new ArrayList<>());

    @Override public void add(double v) { data.add(v); }
    @Override public List<Double> getAll() { return new ArrayList<>(data); }
}
