package ec.asgmt.jms;

import javax.ejb.Local;

@Local
public interface StatsJMSStatelessLocal {
    void produce(String message);   // sends to Queue (StatsQueue)
    void publish(String data);      // publishes to Topic (StatsTopic)
}
