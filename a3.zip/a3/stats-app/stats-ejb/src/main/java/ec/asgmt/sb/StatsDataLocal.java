package ec.asgmt.sb;

import java.util.List;
import javax.ejb.Local;

@Local
public interface StatsDataLocal {
    void add(double v);
    List<Double> getAll();
}
