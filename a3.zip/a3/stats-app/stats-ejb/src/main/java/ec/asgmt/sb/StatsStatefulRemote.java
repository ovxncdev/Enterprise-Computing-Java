package ec.asgmt.sb;

import javax.ejb.Remote;

@Remote
public interface StatsStatefulRemote{

void insertData(double a);
void createModel();
String getStats();
int getCount();



}