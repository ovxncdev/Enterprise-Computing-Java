package ec.asgmt.sb;
import javax.ejb.Remote;

@Remote
public interface StatsSingletonRemote {
    void addData(double a);
    int getCount();
    String stats();
    void saveModel();
}
