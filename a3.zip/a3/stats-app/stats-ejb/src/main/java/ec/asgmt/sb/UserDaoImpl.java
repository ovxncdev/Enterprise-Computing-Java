package ec.asgmt.sb;

import ec.asgmt.entity.User;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.security.MessageDigest;
import java.util.Formatter;
import java.util.List;

/**
 * Stateful User DAO.
 * Note: getUser expects the *encrypted* (MD5 hex) password per spec.
 * To be robust, if a plaintext is passed, we’ll MD5 it before querying.
 */
@Stateful
@Local(UserDao.class)
@LocalBean
public class UserDaoImpl implements UserDao {

    @PersistenceContext(unitName = "primary")
    private EntityManager em;

    @Override
    public void addUser(User user) {
        if (user == null) return;
        // normalize: if password looks non-hex, hash it
        String pwd = user.getPassword();
        if (pwd != null && !isHex32(pwd)) {
            user.setPassword(md5Hex(pwd));
        }
        em.persist(user);
    }

    @Override
    public User getUser(String name, String password) {
        if (name == null || password == null) return null;

        // If caller passed plaintext (not 32-hex), hash it.
        String enc = isHex32(password) ? password : md5Hex(password);

        TypedQuery<User> q = em.createQuery(
                "SELECT u FROM User u WHERE u.name = :name AND u.password = :pwd",
                User.class);
        q.setParameter("name", name);
        q.setParameter("pwd", enc);

        List<User> list = q.getResultList();
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public List<User> getAllUser() {
        return em.createQuery("SELECT u FROM User u ORDER BY u.id", User.class)
                 .getResultList();
    }

    // -------- helpers --------
    private static boolean isHex32(String s) {
        return s != null && s.matches("(?i)^[0-9a-f]{32}$");
    }

    private static String md5Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] dig = md.digest(s.getBytes("UTF-8"));
            try (Formatter f = new Formatter()) {
                for (byte b : dig) f.format("%02x", b);
                return f.toString();
            }
        } catch (Exception e) {
            throw new RuntimeException("MD5 error", e);
        }
    }
}
