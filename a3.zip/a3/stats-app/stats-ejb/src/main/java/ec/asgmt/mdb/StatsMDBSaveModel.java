package ec.asgmt.mdb;

import ec.asgmt.StatsSummary;
import ec.asgmt.sb.ModelDao;
import ec.asgmt.sb.StatsSingletonLocal;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.*;
import java.util.HashMap;
import java.util.Map;

/**
 * MDB listening on java:/jms/queue/StatsQueue.
 * Messages: "save" or "save:customName"
 * Builds a StatsSummary from the Singleton's current stats() string and persists it into table ecmodel.
 */
@MessageDriven(
    activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/jms/queue/StatsQueue"),
        @ActivationConfigProperty(propertyName = "destinationType",   propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode",   propertyValue = "Auto-acknowledge")
    }
)
public class StatsMDBSaveModel implements MessageListener {

    @EJB
    private ModelDao modelDao;

    @EJB
    private StatsSingletonLocal singleton;

    @Override
    public void onMessage(Message message) {
        try {
            if (!(message instanceof TextMessage)) {
                System.out.println("[StatsMDBSaveModel] Ignored non-text JMS message: " + message);
                return;
            }

            String txt = ((TextMessage) message).getText();
            if (txt == null) return;
            txt = txt.trim();
            if (!txt.toLowerCase().startsWith("save")) return;

            // allow "save" or "save:myname"
            String name = "stats";
            int colon = txt.indexOf(':');
            if (colon > 0 && colon < txt.length() - 1) {
                name = txt.substring(colon + 1).trim();
            }

            // Build a StatsSummary from the singleton's current string output
            StatsSummary summary = buildCurrentSummaryFromSingleton();

            modelDao.save(name, summary);
            System.out.println("[StatsMDBSaveModel] Saved model '" + name + "' to ecmodel. "
                    + "count=" + summary.getCount()
                    + " min=" + summary.getMin()
                    + " max=" + summary.getMax()
                    + " mean=" + summary.getMean()
                    + " std=" + summary.getSTD());

        } catch (JMSException e) {
            System.err.println("[StatsMDBSaveModel] JMS error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("[StatsMDBSaveModel] Error saving model: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private StatsSummary buildCurrentSummaryFromSingleton() {
        StatsSummary s = new StatsSummary();
        try {
            // Example format produced by your singleton.stats():
            // count:5\nmin:1.0\nmax:9.0\nmean:4.2\nstd:2.1\n
            String statsStr = singleton.stats();
            Map<String, String> map = new HashMap<>();
            if (statsStr != null) {
                for (String line : statsStr.split("\\r?\\n")) {
                    int idx = line.indexOf(':');
                    if (idx > 0) {
                        String k = line.substring(0, idx).trim().toLowerCase();
                        String v = line.substring(idx + 1).trim();
                        map.put(k, v);
                    }
                }
            }
            if (map.containsKey("count")) s.setCount(parseIntSafe(map.get("count")));
            if (map.containsKey("min"))   s.setMin(parseDoubleSafe(map.get("min")));
            if (map.containsKey("max"))   s.setMax(parseDoubleSafe(map.get("max")));
            if (map.containsKey("mean"))  s.setMean(parseDoubleSafe(map.get("mean")));
            if (map.containsKey("std"))   s.setSTD(parseDoubleSafe(map.get("std")));
        } catch (Exception e) {
            // If anything goes wrong, keep defaults and log
            System.err.println("[StatsMDBSaveModel] Failed to parse singleton stats(); saving defaults. " + e.getMessage());
        }
        return s;
    }

    private static int parseIntSafe(String v) {
        try { return Integer.parseInt(v); } catch (Exception e) { return 0; }
    }
    private static double parseDoubleSafe(String v) {
        try { return Double.parseDouble(v); } catch (Exception e) { return 0.0; }
    }
}
