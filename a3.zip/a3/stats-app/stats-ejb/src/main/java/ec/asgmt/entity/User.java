package ec.asgmt.entity;

import javax.persistence.*;

@Entity
@Table(name = "ecuser")
@NamedQueries({
    @NamedQuery(
        name = "User.findByName",
        query = "SELECT u FROM User u WHERE u.name = :name"
    ),
    @NamedQuery(
        name = "User.findByNameAndPassword",
        query = "SELECT u FROM User u WHERE u.name = :name AND u.password = :password"
    )
})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // MySQL AUTO_INCREMENT
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, length = 64) // storing MD5 hex per spec
    private String password;

    @Column(nullable = false)
    private Integer role; // 1=admin, 2=dev, 3=user

    public User() {}

    public User(String name, String password, Integer role) {
        this.name = name;
        this.password = password;
        this.role = role;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Integer getRole() { return role; }
    public void setRole(Integer role) { this.role = role; }

    @Override
    public String toString() {
        return "User{id=" + id + ", name='" + name + "', role=" + role + "}";
    }
}
