# LAB3 Report

Author: Adeniyi Ridwan Adetunji 

Date: 2025-11-04 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
# T1 SOAP Web Services (lab practice)


### T1.1 Hand on helloworld-ws
 

Complete? Yes 

![HELLOWORDL](images/HELLOWORDL.png){width=90%}


### T1.2 ec-ws component
 

Complete? Yes 


![ecwscomponent](images/ecwscomponent.png){width=90%}


### T1.3 ec-ws client
 

Complete? Yes 

![ecwsclient](images/ecwsclient.png){width=90%}



### T1.4 Accessing SOAP WS by Servlet
 

Complete? Yes 

![soapwsbyservelet](images/soapwsbyservelet.png){width=90%}



# T2 RESTful Web Services (lab practice)


### T2.1 Hand on helloworld-rs
 

Complete? Yes 

![helloworldrs](images/helloworldrs.png){width=90%}



### T2.2 ec-rs component
 

Complete? Yes 

![ecrscomponent](images/ecrscomponent.png){width=90%}




# T3 Web Tier Components (lab practice)


### T3.1 Servlet Programming
 

Complete? Yes 


![serveletprogramming](images/serveletprogramming.png){width=90%}


### T3.2 Hand on JSP
 

Complete? Yes 


![handsonjsp](images/handsonjsp.png){width=90%}
![handsonjsf](images/handsonjsf.png){width=90%}
![threetwothree](images/threetwothree.png){width=90%}


### T3.3 Hand on JSF
 

Complete? Yes 

![handsonjsfpr](images/handsonjsfpr.png){width=90%}
![handsonjsflogin](images/handsonjsflogin.png){width=90%}
![handsonjsfadmin](images/handsonjsfadmin.png){width=90%}



# T4 Client tier components (lab practice)


### T4.1 Java HTTP clients
 

Complete? Yes 

![javahttpclient](images/javahttpclient.png){width=90%}

### T4.2 JavaScript Client
 

Complete? Yes 

![contactjquery](images/contactjquery.png){width=90%}
![indexajax](images/indexajax.png){width=90%}
![indexreact](images/indexreact.png){width=90%}


# T5 Enabling SSL on JBoss WildFly Application Server (lab practice)


### T5.1 Hand on default application realm
 

Complete? Yes 

![handsonapprealm](images/handsonapprealm.png){width=90%}


### T5.2 Create Custom EC Application Realm
 

Complete? Yes 

![SSLonapp](images/SSLonapp.png){width=90%}




**References**

1. CP630OC lab3
2. Add your references if you used any. 
