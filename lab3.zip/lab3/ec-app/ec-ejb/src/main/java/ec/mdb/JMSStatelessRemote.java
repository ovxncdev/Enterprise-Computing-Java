package ec.mdb;

public interface JMSStatelessRemote {
    boolean sendMessageToQueue(String text);
    boolean sendMessageToTopic(String text);
}
