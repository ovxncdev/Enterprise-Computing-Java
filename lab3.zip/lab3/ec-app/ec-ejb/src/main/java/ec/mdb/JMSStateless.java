package ec.mdb;

import javax.annotation.Resource;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSRuntimeException;
import javax.jms.Queue;
import javax.jms.Topic;

@Stateless(name = "JMSMessenger") // <— unique bean name
@Remote(JMSStatelessRemote.class)
public class JMSStateless implements JMSStatelessRemote {

    @Resource(lookup = "java:/JmsXA")
    private ConnectionFactory cf;

    @Resource(lookup = "java:/jms/queue/StatsQueue")
    private Queue statsQueue;

    @Resource(lookup = "java:/jms/topic/StatsTopic")
    private Topic statsTopic;

    @Override
    public boolean sendMessageToQueue(String text) {
        try (JMSContext ctx = cf.createContext()) {
            ctx.createProducer().send(statsQueue, text);
            return true;
        } catch (JMSRuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean sendMessageToTopic(String text) {
        try (JMSContext ctx = cf.createContext()) {
            ctx.createProducer().send(statsTopic, text);
            return true;
        } catch (JMSRuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }
}
