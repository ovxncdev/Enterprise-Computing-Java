package ec.lab;
import javax.ejb.Local;

@Local
public interface SBStatelessLocal {
    String getPrediction(int a);
    String getSBType();
    int getCounter();
}