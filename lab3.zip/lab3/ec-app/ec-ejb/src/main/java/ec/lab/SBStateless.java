
package ec.lab;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Stateless(name = "SBStatelessBean")                  // unique name
@Local(SBStatelessLocal.class)
@Remote(SBStatelessRemote.class)
public class SBStateless implements SBStatelessRemote, SBStatelessLocal {

    @EJB
    private SBSingletonLocal sbsgt;

    @Override public String getSBType() { return "stateless"; }

    @Override
    public String getPrediction(int a) {
        sbsgt.incCounter();
        return a >= 70 ? "Pass" : "Fail";
    }

    @Override public int getCounter() { return sbsgt.getCounter(); }
}
