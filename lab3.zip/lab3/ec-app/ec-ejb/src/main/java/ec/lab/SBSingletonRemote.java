package ec.lab;
import javax.ejb.Remote;

@Remote
public interface SBSingletonRemote {
    int incCounter();    
    int getCounter();
    String getSBType();
}
