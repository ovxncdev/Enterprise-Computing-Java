package ec.mdb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import ec.lab.SBStatelessLocal;

@MessageDriven(
    name = "sub1",
    activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationType",  propertyValue = "javax.jms.Topic"),
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/jms/topic/test")
    }
)
public class ECMDBSubscriber1 implements MessageListener {

    @EJB(beanName = "SBStatelessBean")
    private SBStatelessLocal sbsl;

    @Override
    public void onMessage(Message message) {
        try {
            String mstr = ((TextMessage) message).getText();
            System.out.println("Message received by subscriber1 : " + mstr);
            System.out.println("Subscriber1 invoking get Type: " + sbsl.getSBType());
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
