package ec.lab;
import javax.ejb.Local;

@Local
public interface SBSingletonLocal {
    int incCounter();     
    int getCounter();
    String getSBType();
}
