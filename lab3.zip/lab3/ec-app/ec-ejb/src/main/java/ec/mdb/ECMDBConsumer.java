package ec.mdb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import ec.lab.SBStatelessLocal;

@MessageDriven(
    name = "testQueue",
    activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationType",  propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/jms/queue/test")
    }
)
public class ECMDBConsumer implements MessageListener {

    @EJB(beanName = "SBStatelessBean")
    private SBStatelessLocal sbsl;

    @Override
    public void onMessage(Message message) {
        try {
            String mstr = ((TextMessage) message).getText();
            System.out.println("Message received by consumer : " + mstr);
            System.out.println("Consumer invoking get Type: " + sbsl.getSBType());
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
