JobID: cp630oc-lab3
Name: Adeniyi Ridwan Adetunji
ID: 245852450

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab3

T1 SOAP Web Services
T1.1 [3/3/*] Hand on helloworld-ws
T1.2 [5/5/*] ec-ws component
T1.3 [4/4/*] ec-ws client
T1.4 [4/4/*] Accessing SOAP WS by Servlet

T2 RESTful Web Services
T2.1 [3/3/*] Hand on helloworld-rs
T2.2 [5/5/*] ec-rs component

T3 Web Tier Components
T3.1 [5/5/*] Servlet Programming
T3.2 [3/3/*] Hand on JSP
T3.3 [3/3/*] Hand on JSF

T4 Client tier components
T4.1 [4/4/*] Java HTTP clients
T4.2 [4/4/*] JavaScript Client

T5 Enabling SSL on JBoss WildFly Application Server
T5.1 [3/3/*] Hand on default application realm
T5.2 [4/4/*] Create Custom EC Application Realm

Total: [50/50/*]