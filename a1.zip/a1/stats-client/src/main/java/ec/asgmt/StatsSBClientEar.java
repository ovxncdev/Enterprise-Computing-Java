package ec.asgmt;

import ec.asgmt.sb.StatsSingletonRemote;
import ec.asgmt.sb.StatsStatefulRemote;
import ec.asgmt.sb.StatsStatelessRemote;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

public class StatsSBClientEar {
    private static final Logger logger =
            LogManager.getLogger(StatsSBClientEar.class.getName());

    public static void main(String[] args) throws Exception {
        // Build JNDI env explicitly (works even without jndi.properties)
        InitialContext ic = buildInitialContext();

        // 1) Singleton: add 1..10 and save model
        StatsSingletonRemote singleton = (StatsSingletonRemote) ic.lookup(
            "stats-ear/stats-ejb/StatsSingleton!ec.asgmt.sb.StatsSingletonRemote"
        );
        for (int i = 1; i <= 10; i++) singleton.addData(i);
        singleton.saveModel();
        System.out.println("Added 1..10 and saved model.");
        logger.info("RMI of StatsSingleton");

        // 2) Stateless: query simple stats
        StatsStatelessRemote stateless = (StatsStatelessRemote) ic.lookup(
            "stats-ear/stats-ejb/StatsStateless!ec.asgmt.sb.StatsStatelessRemote"
        );
        System.out.println("Count: " + stateless.getCount());
        System.out.println("Mean : " + stateless.getMean());
        logger.info("RMI of StatsStateless");

        // 3) Stateful: insert 11..100, save, print summary
        StatsStatefulRemote stateful = (StatsStatefulRemote) ic.lookup(
            "stats-ear/stats-ejb/StatsStateful!ec.asgmt.sb.StatsStatefulRemote"
        );
        for (int i = 11; i <= 100; i++) stateful.insertData(i);
        stateful.createModel();
        System.out.println(stateful.getStats());
        logger.info("RMI of StatsStateful");

        logger.info("RMI of stats-ejb is done!");
    }

    private static InitialContext buildInitialContext() throws NamingException {
        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "org.jboss.naming.remote.client.InitialContextFactory");
        env.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
        // Let short names like "app/module/Bean!iface" resolve:
        env.put("jboss.naming.client.ejb.context", "true");

        // If your WildFly requires auth, uncomment:
        // env.put(Context.SECURITY_PRINCIPAL, "user");
        // env.put(Context.SECURITY_CREDENTIALS, "password");

        return new InitialContext(env);
    }
}
