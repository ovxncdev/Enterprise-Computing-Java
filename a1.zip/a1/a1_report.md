# A1 Report

Author: ADENIYI RIDWAN ADETUNJI 

Date: 2025-09-23 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 EC story

Enterprise computing are essential for organizations that require robust, scalable, effective and efficient systems to handle complex business operations. In my experience, I have worked with WildFly, an open-source Java-based application server used to host enterprise applications. Developers, system administrators, and IT teams use WildFly to deploy Java EE (Enterprise Edition) applications, such as web services, REST APIs, and EJBs.

The primary problem WildFly addresses is managing complex enterprise applications that involve multiple services, databases, and messaging systems. 

I learnt how to use both server and eclipse which is an IDE to run xml pages and connect with other java objects efficently while sending request to server and getting responses instantly.

WildFly uses Java as its core technology and leverages related frameworks such as EJB, JSF, RESTEasy, Infinispan etc for caching and high-performance computing. Administrators benefit from its management console and Command Line Interface tools, which help monitor, deploy, and manage applications efficiently.

Through the practical experiences i have gained, I realized that enterprise computing solutions like WildFly are essential for building scalable, reliable, and maintainable applications. They remove  infrastructure complexity and allow teams to deliver business value quickly. The experience also reinforced the importance of understanding both the application layer and the computing technology it uses, including Java, messaging, and transaction management, to build robust enterprise systems.

## Q2 Descriptive statistics computing project (programming)


### Q2.1 Creating pom.xml

Complete? Yes 

![tone](images/tone.png){width=90%}



### Q2.2 Interface design

Complete? Yes 

![two](images/two.png){width=90%}


### Q2.3 Implementation

Complete? Yes 

![tthree](images/tthree.png){width=90%}



### Q2.4 Main program

Complete? Yes 

![tfour](images/tfour.png){width=90%}



### Q2.5 JUnit test

Complete? Yes 

![test](images/test.png){width=90%}



### Q2.6 Logging and documentation

Complete? Yes 

![logginndocs](images/logginndocs.png){width=90%}



## Q3 Java EE project on stats (programming)


### Q3.1 stats-app

Complete? Yes 

![tiri1](images/tiri1.png){width=90%}



### Q3.2 stats-ejb

Complete? Yes 


![tiri2](images/tiri2.png){width=90%}


### Q3.3 stats-web

Complete? Yes 


![statweb](images/statweb.png){width=90%}


### Q3.4 stats-ear

Complete?  Yes 

![deploy](images/deploy.png){width=90%}

![testpage](images/testpage.png){width=90%}


### Q3.5 stats-client

Complete?  Yes 

![statsclient](images/statsclient.png){width=90%}



## Q4 Batch test (test)


### Q4.1  Create test output

Complete?  Yes 

[test output](test_output.txt)





**References**

1. CP630 a1
2. Add your references if you used any. 
