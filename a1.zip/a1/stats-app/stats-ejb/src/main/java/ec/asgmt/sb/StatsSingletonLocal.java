package ec.asgmt.sb;
import javax.ejb.Local;

@Local
public interface StatsSingletonLocal {
    void addData(double a);
    int getCount();
    String stats();          // compute & return summary string
    void saveModel();        // serialize StatsSummary to file
}
