package ec.asgmt.sb;
import javax.ejb.Local;

@Local
public interface StatsStatelessLocal {
    int getCount();
    double getMin();
    double getMax();
    double getMean();
    double getSTD();
    String toString();
    ec.asgmt.StatsSummary loadModel(); // explicit as per spec
}
