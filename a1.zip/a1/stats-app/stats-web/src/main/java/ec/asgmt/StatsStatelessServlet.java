package ec.asgmt;

import ec.asgmt.sb.StatsStatelessLocal;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class StatsStatelessServlet extends HttpServlet {

    @EJB(lookup = "java:global/stats-ear/stats-ejb/StatsStateless!ec.asgmt.sb.StatsStatelessLocal")
    private StatsStatelessLocal stateless;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String q = req.getParameter("value"); // count|min|max|mean|std|summary
        String body;

        try {
            ensureStateless();

            if (q == null) {
                write(resp, "Query missing. Use value=count|min|max|mean|std|summary", 400);
                return;
            }

            switch (q) {
                case "count":   body = String.valueOf(stateless.getCount()); break;
                case "min":     body = String.valueOf(stateless.getMin());   break;
                case "max":     body = String.valueOf(stateless.getMax());   break;
                case "mean":    body = String.valueOf(stateless.getMean());  break;
                case "std":     body = String.valueOf(stateless.getSTD());   break;
                case "summary":
                default:        body = stateless.toString();                 break;
            }

            write(resp, body, 200);

        } catch (Exception e) {
            write(resp, "Error: " + e.getClass().getSimpleName() + " - " + e.getMessage(), 500);
        }
    }

    private void ensureStateless() throws NamingException {
        if (stateless == null) {
            InitialContext ic = new InitialContext();
            stateless = (StatsStatelessLocal) ic.lookup(
                "java:global/stats-ear/stats-ejb/StatsStateless!ec.asgmt.sb.StatsStatelessLocal"
            );
        }
    }

    private void write(HttpServletResponse resp, String body, int status) throws IOException {
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain;charset=UTF-8");
        byte[] bytes = body.getBytes("UTF-8");
        resp.setContentLength(bytes.length);
        try (PrintWriter out = resp.getWriter()) { out.write(body); }
    }
}
