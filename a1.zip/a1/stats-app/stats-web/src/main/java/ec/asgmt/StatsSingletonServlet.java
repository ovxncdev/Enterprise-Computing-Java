package ec.asgmt;

import ec.asgmt.sb.StatsSingletonLocal;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class StatsSingletonServlet extends HttpServlet {

    // Try container injection first; fallback to manual lookup if null
    @EJB(lookup = "java:global/stats-ear/stats-ejb/StatsSingleton!ec.asgmt.sb.StatsSingletonLocal")
    private StatsSingletonLocal singleton;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String sv = req.getParameter("value");
        String body;

        try {
            // Ensure we have the EJB reference
            ensureSingleton();

            if (sv == null || sv.trim().isEmpty()) {
                body = "No value provided.";
            } else {
                double v = Double.parseDouble(sv);
                singleton.addData(v);
                singleton.saveModel();
                body = sv + " added, model saved.";
            }

            write(resp, body, 200);

        } catch (NumberFormatException nfe) {
            write(resp, "Error: invalid number: " + sv, 400);
        } catch (Exception e) {
            write(resp, "Error: " + e.getClass().getSimpleName() + " - " + e.getMessage(), 500);
        }
    }

    private void ensureSingleton() throws NamingException {
        if (singleton == null) {
            InitialContext ic = new InitialContext();
            singleton = (StatsSingletonLocal) ic.lookup(
                "java:global/stats-ear/stats-ejb/StatsSingleton!ec.asgmt.sb.StatsSingletonLocal"
            );
        }
    }

    private void write(HttpServletResponse resp, String body, int status) throws IOException {
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain;charset=UTF-8");
        byte[] bytes = body.getBytes("UTF-8");
        resp.setContentLength(bytes.length);
        try (PrintWriter out = resp.getWriter()) {
            out.write(body);
        }
    }
}
