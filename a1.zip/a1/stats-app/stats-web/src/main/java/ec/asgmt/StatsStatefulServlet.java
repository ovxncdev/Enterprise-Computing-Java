package ec.asgmt;

import ec.asgmt.sb.StatsStatefulLocal;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class StatsStatefulServlet extends HttpServlet {

    @EJB(lookup = "java:global/stats-ear/stats-ejb/StatsStateful!ec.asgmt.sb.StatsStatefulLocal")
    private StatsStatefulLocal stateful;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String sv = req.getParameter("value");
        String body;

        try {
            ensureStateful();

            if (sv == null || sv.trim().isEmpty()) {
                write(resp, "No value provided.", 400);
                return;
            }

            double v = Double.parseDouble(sv);
            stateful.insertData(v);
            stateful.createModel();

            // Return multi-line summary
            body = stateful.getStats();
            write(resp, body, 200);

        } catch (NumberFormatException nfe) {
            write(resp, "Error: invalid number: " + sv, 400);
        } catch (Exception e) {
            write(resp, "Error: " + e.getClass().getSimpleName() + " - " + e.getMessage(), 500);
        }
    }

    private void ensureStateful() throws NamingException {
        if (stateful == null) {
            InitialContext ic = new InitialContext();
            stateful = (StatsStatefulLocal) ic.lookup(
                "java:global/stats-ear/stats-ejb/StatsStateful!ec.asgmt.sb.StatsStatefulLocal"
            );
        }
    }

    private void write(HttpServletResponse resp, String body, int status) throws IOException {
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain;charset=UTF-8");
        byte[] bytes = body.getBytes("UTF-8");
        resp.setContentLength(bytes.length);
        try (PrintWriter out = resp.getWriter()) { out.write(body); }
    }
}
