JobID: cp630oc-a1
Name: Adeniyi Ridwan Adetunji
ID: 245852450

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A1

Q1 EC story
Q1.1 [5/5/*] Recognition of EC problems, products and services
Q1.2 [5/5/*] What it is and how it is used           
Q1.3 [5/5/*] Problem and solving and computing platform technology

Q2 Descriptive statistics computing project
Q2.1 [5/5/*] Creating pom.xml                        
Q2.2 [5/5/*] Interface design                        
Q2.3 [20/20/*] Implementation                          
Q2.4 [5/5/*] Main program                            
Q2.5 [5/5/*] JUnit test                              
Q2.6 [5/5/*] Logging and documentation               

Q3 Java EE project on stats
Q3.1 [5/5/*] stats-app                               
Q3.2 [15/15/*] stats-ejb                               
Q3.3 [5/5/*] stats-web                               
Q3.4 [5/5/*] stats-ear                               
Q3.5 [5/5/*] stats-client                            

Q4 Batch test
Q4.1 [5/5/*]  Create test output                     

Total: [100/100/*]

