Stats Maven Project (stats-mvn)


A Maven project to compute simple descriptive statistics (count, min, max, mean, standard deviation) using both incremental and batch algorithms.

## How to Build
#from teh root folder 

mvn clean package

## to run
java -jar target/stats-mvn.jar

