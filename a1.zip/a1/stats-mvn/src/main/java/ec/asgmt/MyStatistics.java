package ec.asgmt;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MyStatistics {
private static final Logger logger = LogManager.getLogger(MyStatistics.class.getName());  

    public static void main(String[] args) {


        ECStatistics stats = new ECStatistics();

        
        for (double i = 1; i <= 10000; i++) {
            stats.addData(i);
        }

        
        stats.stats();

        
        System.out.println("Count: " + stats.getCount());
        System.out.println("Min: " + stats.getMin());
        System.out.println("Max: " + stats.getMax());
        System.out.println("Mean: " + stats.getMean());
        System.out.println("STD: " + stats.getSTD());

//loggers
logger.info("The count is " + stats.getCount());
logger.info("The Minimum is " + stats.getMin());
logger.info("The Maximum is " + stats.getMax());
logger.info("The Mean is " + stats.getMean());
logger.info("The Standard Deviation is " + stats.getSTD());
    }
}
