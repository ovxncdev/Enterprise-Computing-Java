package ec.asgmt;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import ec.asgmt.Statistics;

public class StatisticsTest {
    private ECStatistics stats;

    @Before
    public void setup() {
        stats = new ECStatistics();
        stats.addData(1);
        stats.addData(2);
        stats.addData(3);
        stats.addData(4);
        stats.addData(5);
    }

 @Test
public void testStats() {
    stats.stats();
    System.out.println("Mean: " + stats.getMean());
    System.out.println("STD: " + stats.getSTD());
    assertEquals(5, stats.getCount());
    assertEquals(1, stats.getMin(), 0.001);
    assertEquals(5, stats.getMax(), 0.001);
    assertEquals(3, stats.getMean(), 0.001);
    assertEquals(Math.sqrt(2), stats.getSTD(), 0.001);
}
}