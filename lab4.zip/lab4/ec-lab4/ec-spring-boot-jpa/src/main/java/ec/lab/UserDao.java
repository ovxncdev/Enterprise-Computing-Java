package ec.lab;

import java.util.List;
public interface UserDao {
//    User save(User user);
//    void createUser(User user);
    List<User> findAll();
//    User findById(Integer id);
//    User findByID(int id);
//    User findByName(String name);
//    void removeUserByID(Integer id);
//    void removeAll();
}

