package ec.spring.boot;

public interface GradeServiceI {
    String getGrade(int score);
}