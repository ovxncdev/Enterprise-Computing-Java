package ec.lab;

public class ECSpring  {
	private String name;
	public void setName(String name) {
		this.name = name;
	}
	public void printHello() {
		System.out.println("Hello " + name);
	}
	public String getName() {
		return name;
	}
}
