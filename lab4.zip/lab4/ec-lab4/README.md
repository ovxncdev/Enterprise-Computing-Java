# CP-630-EC Lab4

Author: HBF  

## About this package

This package contains practice projects of Lab4. It is about basics of JavaEE programming, packaging and deployment. It is for trouble shooting of Lab4 practices.  

## How to use the package

Extract the package to a folder, say lab4-clone. When working on your lab1 projects, if you run into issues and can not resolve your projects, you can check the code and structure of the package to fix your projects. 
