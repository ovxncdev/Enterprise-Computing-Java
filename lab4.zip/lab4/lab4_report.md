# LAB4 Report

Author: Adeniyi Ridwan Adetunji 

Date: 2025-11-11 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
# T1 Spring Framework (lab practice)


### T1.1 Hand on IoC
 

Complete? Yes o


![HandonIoC1](images/HandonIoC1.png){width=90%}
![HandonIoC2](images/HandonIoC2.png){width=90%}

### T1.2 Hand on AOP
 

Complete? Yes 

![HandonAOP](images/HandonAOP.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### T1.3 Web component of Spring MVC
 

Complete? Yes 


![WebcomponentofSpringMVC](images/WebcomponentofSpringMVC.png){width=90%}



### T1.4 Spring Boot Web applications
 

Complete? Yes 


![Spring-Boot-Web-applications](images/Spring-Boot-Web-applications.png){width=90%}



### T1.5 Spring on WildFly
 

Complete? Yes o

![Spring-on-WildFly](images/Spring-on-WildFly.png){width=90%}




# T2 OSGi Framework (lab practice)


### T2.1 Equinox OSGi framework
 

Complete? Yes 

![Equinox-OSGi-framework](images/Equinox-OSGi-framework.png){width=90%}



### T2.2 Creating OSGi bundles
 

Complete? Yes 


![Creating-OSGi-bundles](images/Creating-OSGi-bundles.png){width=90%}



### T2.3 Apache Felix
 

Complete? Yes 

![Apache-Felix](images/Apache-Felix.png){width=90%}



### T2.4 Apache Karaf
 

Complete? Yes 

![Apache-Karaf](images/Apache-Karaf.png){width=90%}




# T3 OSGi Service Bundle development (lab practice)


### T3.1 OSGi service bundle
 

Complete? Yes

![OSGi-service-bundle](images/OSGi-service-bundle.png){width=90%}



### T3.2 ec-osgi-consumer bundle
 

Complete? Yes 

![ec-osgi-consumer-bundle](images/ec-osgi-consumer-bundle.png){width=90%}



### T3.3 Servlet bundles
 

Complete? Yes 

![Servlet-bundles](images/Servlet-bundles.png){width=90%}


# T4 Docker (lab practice)


### T4.1 Install Docker and operations
 

Complete? Yes 


![dockerandop](images/dockerandop.png){width=90%}



### T4.2 Creating docker images
 

Complete? Yes 


![dockerimages](images/dockerimages.png){width=90%}
![dockerimages2](images/dockerimages2.png){width=90%}


### T4.3 Microservices on docker container
 

Complete? Yes 


![microserviceondocker](images/microserviceondocker.png){width=90%}

![microserviceondocker2](images/microserviceondocker2.png){width=90%}



# T5 Container orchestration (optional, no marks) (lab practice)


### T5.1 Install and run Microk8s
 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->

### T5.2 Basic operations on Microk8s
 

Complete? Yes or No 

<!--If you answer Yes, insert one or more screenshot images to show the completion.-->

![Image caption](images/demo.png){width=90%}

<!-- If No, add a short description to describe the issues encountered.-->


# T6 Hand on Jenkins (lab practice)


### T6.1 Installing and starting Jenkins
 

Complete? Yes 

![installjenkins](images/installjenkins.png){width=90%}



### T6.2 Jenkins Global Tool Configurations and Plugins
 

Complete? Yes 

![jenkinstools1](images/jenkinstools1.png){width=90%}
![jenkinstools2](images/jenkinstools2.png){width=90%}
![jenkinstools3](images/jenkinstools3.png){width=90%}

### T6.3 Creating Jenkins Jobs
 

Complete? Yes 

![jkjob1](images/jkjob1.png){width=90%}
![jkjob2](images/jkjob2.png){width=90%}
![jkjob3](images/jkjob3.png){width=90%}
![jkjob4](images/jkjob4.png){width=90%}

**References**

1. CP630OC lab4
2. Add your references if you used any. 
