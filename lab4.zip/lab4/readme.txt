JobID: cp630oc-lab4
Name: Adeniyi Ridwan Adetunji
ID: 245852450

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab4

T1 Spring Framework
T1.1 [2/2/*] Hand on IoC
T1.2 [2/2/*] Hand on AOP
T1.3 [2/2/*] Web component of Spring MVC
T1.4 [2/2/*] Spring Boot Web applications
T1.5 [2/2/*] Spring on WildFly

T2 OSGi Framework
T2.1 [2/2/*] Equinox OSGi framework
T2.2 [2/2/*] Creating OSGi bundles
T2.3 [2/2/*] Apache Felix
T2.4 [2/2/*] Apache Karaf

T3 OSGi Service Bundle development
T3.1 [3/3/*] OSGi service bundle
T3.2 [3/3/*] ec-osgi-consumer bundle
T3.3 [3/3/*] Servlet bundles

T4 Docker
T4.1 [2/2/*] Install Docker and operations
T4.2 [2/2/*] Creating docker images
T4.3 [2/2/*] Microservices on docker container

T5 Container orchestration (optional, no marks)
T5.1 [0/0/*] Install and run Microk8s
T5.2 [0/0/*] Basic operations on Microk8s

T6 Hand on Jenkins
T6.1 [2/2/*] Installing and starting Jenkins
T6.2 [2/2/*] Jenkins Global Tool Configurations and Plugins
T6.3 [3/3/*] Creating Jenkins Jobs

Total: [40/40/*]