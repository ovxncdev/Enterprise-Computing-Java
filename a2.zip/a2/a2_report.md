# A2 Report

Author: Adeniyi Ridwan Adetunji

Date: 2025-10-10 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 JMS and MDB for Statistics Application (programming)


### Q1.1 Message Queue MDB

Complete? Yes 

![onesavemodel](images/onesavemodel.png){width=90%}



### Q1.2 Message Topic MDB

Complete? Yes


![onetwotopic](images/onetwotopic.png){width=90%}



### Q1.3 JMS clients

Complete? Yes 


![onethreejms](images/onethreejms.png){width=90%}



### Q1.4 JMS Clients within Servlet

Complete? Yes 

![onefourjms](images/onefourjms.png){width=90%}



### Q1.5 JMS Clients within Session Beans 

Complete? Yes 


![onefive](images/onefive.png){width=90%}



## Q2 Data persistence for Statistics Application (programming)


### Q2.1 DB Client and CRUD Operations

Complete? Yes 


![DBclnCRUD](images/DBclnCRUD.png){width=90%}



### Q2.2 User Entity Bean

Complete? Yes 


![twotwodone](images/twotwodone.png){width=90%}



### Q2.3 Using User Entity Beans

Complete? Yes 

![twothreelogin](images/twothreelogin.png){width=90%}
![twothreeadmin](images/twothreeadmin.png){width=90%}
![twothreedeveloper](images/twothreedeveloper.png){width=90%}
![twothreeguest](images/twothreeguest.png){width=90%}

### Q2.4 Model Entity Bean

Complete? Yes 

![twofourdone](images/twofourdone.png){width=90%}



### Q2.5 Using Model Entity Bean

Complete? Yes o

![twofivelast](images/twofivelast.png){width=90%}




## Q3 Batch test (test)


### Q3.1  Create test output

Complete? Yes 

[test output](test_output.txt)





**References**

1. CP630 a2
2. Add your references if you used any. 
