package ec.asgmt.jms;

import java.io.IOException;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/producer")
public class StatsJMSProducerServlet extends HttpServlet {

    @Inject
    private JMSContext jms;

    // Primary: container injects it
    @Resource(lookup = "java:/jms/queue/StatsQueue")
    private Queue statsQueue;

    // Fallback: manual JNDI lookup if injection failed
    private Queue resolveQueue() {
        if (statsQueue != null) return statsQueue;
        try {
            InitialContext ic = new InitialContext();
            // try local name first
            Object q = ic.lookup("java:/jms/queue/StatsQueue");
            if (q instanceof Queue) return (Queue) q;
            // try exported name as fallback
            q = ic.lookup("java:jboss/exported/jms/queue/StatsQueue");
            if (q instanceof Queue) return (Queue) q;
        } catch (NamingException ignored) {}
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String msg = req.getParameter("message");
        if (!"save".equalsIgnoreCase(msg)) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().println("Expected ?message=save");
            return;
        }

        Queue q = resolveQueue();
        if (q == null) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().println("Queue not found via JNDI: tried java:/jms/queue/StatsQueue and java:jboss/exported/jms/queue/StatsQueue");
            return;
        }

        jms.createProducer().send(q, "save");
        resp.getWriter().println("Sent 'save' to queue StatsQueue");
    }
}
