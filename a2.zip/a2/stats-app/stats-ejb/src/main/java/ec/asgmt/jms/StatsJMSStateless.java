package ec.asgmt.jms;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.jms.Topic;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@Stateless(name = "StatsJMSStateless") // <— gives us stable JNDI names
public class StatsJMSStateless implements StatsJMSStatelessLocal {

    @Resource(lookup = "java:/JmsXA")
    private ConnectionFactory connectionFactory;

    @Resource(lookup = "java:/jms/queue/StatsQueue")
    private Queue injectedQueue;

    @Resource(lookup = "java:/jms/topic/StatsTopic")
    private Topic injectedTopic;

    private Queue resolveQueue() {
        if (injectedQueue != null) return injectedQueue;
        try {
            InitialContext ic = new InitialContext();
            Object q = ic.lookup("java:/jms/queue/StatsQueue");
            if (q instanceof Queue) return (Queue) q;
            q = ic.lookup("java:jboss/exported/jms/queue/StatsQueue");
            if (q instanceof Queue) return (Queue) q;
        } catch (NamingException ignored) {}
        throw new IllegalStateException("StatsQueue not found in JNDI");
    }

    private Topic resolveTopic() {
        if (injectedTopic != null) return injectedTopic;
        try {
            InitialContext ic = new InitialContext();
            Object t = ic.lookup("java:/jms/topic/StatsTopic");
            if (t instanceof Topic) return (Topic) t;
            t = ic.lookup("java:jboss/exported/jms/topic/StatsTopic");
            if (t instanceof Topic) return (Topic) t;
        } catch (NamingException ignored) {}
        throw new IllegalStateException("StatsTopic not found in JNDI");
    }

    @Override
    public void produce(String message) {
        try (JMSContext ctx = connectionFactory.createContext()) {
            ctx.createProducer().send(resolveQueue(), message);
        }
    }

    @Override
    public void publish(String data) {
        try (JMSContext ctx = connectionFactory.createContext()) {
            ctx.createProducer().send(resolveTopic(), data);
        }
    }
}
