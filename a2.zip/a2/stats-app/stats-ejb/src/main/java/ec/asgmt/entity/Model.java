package ec.asgmt.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ecmodel")
public class Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name="name", nullable=false, unique=true, length=100)
    private String name;

    // Java serialization bytes of the model object
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name="object", nullable=false)
    private byte[] object;

    @Column(name="classname", nullable=false, length=255)
    private String classname;

    @Column(name="date", nullable=false)
    private LocalDateTime date;

    @PrePersist
    public void onCreate() {
        if (date == null) date = LocalDateTime.now();
    }

    // getters/setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public byte[] getObject() { return object; }
    public void setObject(byte[] object) { this.object = object; }

    public String getClassname() { return classname; }
    public void setClassname(String classname) { this.classname = classname; }

    public LocalDateTime getDate() { return date; }
    public void setDate(LocalDateTime date) { this.date = date; }
}
