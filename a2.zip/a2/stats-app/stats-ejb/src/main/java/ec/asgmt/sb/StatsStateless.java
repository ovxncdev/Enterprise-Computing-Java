package ec.asgmt.sb;

import ec.asgmt.StatsSummary;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

@Stateless
@LocalBean
public class StatsStateless implements StatsStatelessRemote, StatsStatelessLocal {

    private static final String MODEL_FILE = "C:/enterprise/tmp/model/stats.bin";
    private StatsSummary sm;

    @Override
    public StatsSummary loadModel() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(MODEL_FILE))) {
            sm = (StatsSummary) ois.readObject();
            return sm;
        } catch (Exception e) {
            sm = null;
            return null;
        }
    }

    private void ensureLoaded() {
        if (sm == null) sm = loadModel();
    }

    @Override public int getCount() { ensureLoaded(); return sm != null ? sm.getCount() : 0; }
    @Override public double getMin() { ensureLoaded(); return sm != null ? sm.getMin() : 0; }
    @Override public double getMax() { ensureLoaded(); return sm != null ? sm.getMax() : 0; }
    @Override public double getMean(){ ensureLoaded(); return sm != null ? sm.getMean(): 0; }
    @Override public double getSTD() { ensureLoaded(); return sm != null ? sm.getSTD() : 0; }

    @Override
    public String toString() {
        ensureLoaded();
        return sm != null ? sm.toString() : "No model loaded";
    }
}