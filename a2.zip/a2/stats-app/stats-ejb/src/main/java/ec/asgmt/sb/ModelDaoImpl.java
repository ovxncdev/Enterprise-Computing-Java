package ec.asgmt.sb;

import ec.asgmt.entity.Model;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.List;

@Stateful
public class ModelDaoImpl implements ModelDao {

    @PersistenceContext(unitName = "primary")
    private EntityManager em;

    // ===== Assignment-required methods =====
    @Override
    public void saveModel(Model model) {
        if (model == null || model.getName() == null || model.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Model and model.name must not be null/empty");
        }
        Model existing = get(model.getName().trim());
        if (existing == null) {
            em.persist(model);
        } else {
            existing.setObject(model.getObject());
            existing.setClassname(model.getClassname());
            existing.setDate(model.getDate());
            em.merge(existing);
        }
    }

    @Override
    public Model getModel(String modelname) {
        return get(modelname);
    }

    // ===== Existing methods (kept for current callers) =====
    @Override
    public void save(String name, Object modelObject) {
        byte[] bytes = serialize(modelObject);
        String className = (modelObject == null) ? "null" : modelObject.getClass().getName();

        Model existing = get(name);
        if (existing == null) {
            Model m = new Model();
            m.setName(name);
            m.setObject(bytes);
            m.setClassname(className);
            em.persist(m);
        } else {
            existing.setObject(bytes);
            existing.setClassname(className);
            em.merge(existing);
        }
    }

    @Override
    public Model get(String name) {
        TypedQuery<Model> q = em.createQuery(
            "SELECT m FROM Model m WHERE m.name = :name", Model.class);
        q.setParameter("name", name);
        List<Model> list = q.getResultList();
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public boolean delete(String name) {
        Model m = get(name);
        if (m != null) {
            em.remove(em.contains(m) ? m : em.merge(m));
            return true;
        }
        return false;
    }

    @Override
    public List<Model> list() {
        return em.createQuery("SELECT m FROM Model m ORDER BY m.id", Model.class)
                 .getResultList();
    }

    private static byte[] serialize(Object obj) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(bos)) {
            oos.writeObject(obj);
            oos.flush();
            return bos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize model object", e);
        }
    }
}
