package ec.asgmt.sb;

import ec.asgmt.entity.User;

import java.util.List;

/**
 * Contract for user management/auth.
 * Note: the `password` parameter is expected to be the encrypted value
 * (MD5 hex). If callers send plaintext, we’ll normalize in the impl.
 */
public interface UserDao {
    void addUser(User user);

    /**
     * Return the matched user or null if not found.
     * The password is the encrypted (MD5 hex) value.
     */
    User getUser(String name, String password);

    List<User> getAllUser();
}
