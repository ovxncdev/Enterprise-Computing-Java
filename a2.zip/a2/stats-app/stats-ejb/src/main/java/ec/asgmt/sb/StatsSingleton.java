package ec.asgmt.sb;

import ec.asgmt.StatsSummary;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@Singleton
@LocalBean

public class StatsSingleton implements StatsSingletonRemote, StatsSingletonLocal{
    private final List<Double> data =  new ArrayList<>();
    private static final String MODEL_DIR = "C:/enterprise/tmp/model";
    private static final String MODEL_FILE = MODEL_DIR + "/stats.bin";

    @Override
    public synchronized void addData(double v){
        data.add(v);
    }

    @Override
    public synchronized int getCount(){

        return data.size();
    }
    @Override
    public synchronized String stats()
{
        StatsSummary s = compute();
        return s.toString();
    }

    private StatsSummary compute() {
        StatsSummary s = new StatsSummary();
        int n = data.size();
        s.setCount(n);
        if (n == 0) return s;

        double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY, sum = 0;
        for (double v : data) {
            if (v < min) min = v;
            if (v > max) max = v;
            sum += v;
        }
        double mean = sum / n;
        double varSum = 0;
        for (double v : data) {
            double d = v - mean;
            varSum += d * d;
        }
        double std = n > 1 ? Math.sqrt(varSum / n) : 0.0;

        s.setMin(min);
        s.setMax(max);
        s.setMean(mean);
        s.setSTD(std);
        return s;
    }

    @Override
    public synchronized void saveModel() {
        try {
            Files.createDirectories(new File(MODEL_DIR).toPath());
            StatsSummary s = compute();
            try (ObjectOutputStream oos =
                         new ObjectOutputStream(new FileOutputStream(MODEL_FILE))) {
                oos.writeObject(s);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to save model: " + e.getMessage(), e);
        }
    }
}