package ec.asgmt.jms;

import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Topic;
import javax.naming.Context;

public class StatsJMSPublisher {
    public static void main(String[] args) throws Exception {
        String value = arg(args, "-message", "10");
        System.out.println("[Publisher] data = " + value);

        Context ctx = null;
        JMSContext jms = null;
        try {
            System.out.println("[Publisher] JNDI…");
            ctx = ContextUtil.getInitialContext();

            System.out.println("[Publisher] Lookup RemoteConnectionFactory…");
            ConnectionFactory cf = (ConnectionFactory) ctx.lookup("jms/RemoteConnectionFactory");

            System.out.println("[Publisher] Lookup topic…");
            Topic topic = (Topic) ctx.lookup("jms/topic/StatsTopic");

            System.out.println("[Publisher] Publish…");
            jms = cf.createContext("quickstartUser", "quickstartPwd1!");
            JMSProducer p = jms.createProducer();
            p.send(topic, value);
            System.out.println("[Publisher] Published to StatsTopic: " + value);
        } finally {
            try { if (jms != null) jms.close(); } catch (Exception ignore) {}
            try { if (ctx != null) ctx.close(); } catch (Exception ignore) {}
            System.out.println("[Publisher] Done.");
        }
    }

    private static String arg(String[] a, String key, String def) {
        for (int i = 0; i < a.length - 1; i++) if (key.equals(a[i])) return a[i+1];
        return def;
    }
}
