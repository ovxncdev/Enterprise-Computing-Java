package ec.asgmt.jms;

import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ContextUtil {
    public static Context getInitialContext() throws NamingException {
        Properties props = new Properties();
        props.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                "org.wildfly.naming.client.WildFlyInitialContextFactory");
        props.setProperty(Context.PROVIDER_URL, "http-remoting://localhost:8080");
        // Application user (guest group) from Lab2 / quickstarts
        props.put(Context.SECURITY_PRINCIPAL, "quickstartUser");
        props.put(Context.SECURITY_CREDENTIALS, "quickstartPwd1!");
        props.put("jboss.naming.client.ejb.context", true);
        return new InitialContext(props);
    }
}
