package ec.asgmt.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StatsDBInsert {

    public static void main(String[] args) throws Exception {
        // Simple argv parser: -key value
        String table = null;
        String name = null;
        String password = null;
        String roleStr = null;
        String modelFile = null;
        String classNameOverride = null; // optional: -classname YourClass

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-table": table = next(args, ++i); break;
                case "-name": name = next(args, ++i); break;
                case "-password": password = next(args, ++i); break;
                case "-role": roleStr = next(args, ++i); break;
                case "-modelfile": modelFile = next(args, ++i); break;
                case "-classname": classNameOverride = next(args, ++i); break;
                default: /* ignore unknown */ ;
            }
        }

        if (table == null) {
            usage("Missing -table");
            return;
        }

        switch (table.toLowerCase()) {
            case "ecuser":
                insertUser(name, password, roleStr);
                break;
            case "ecmodel":
                insertModel(name, modelFile, classNameOverride);
                break;
            default:
                usage("Unknown table: " + table);
        }
    }

    private static void insertUser(String name, String password, String roleStr) throws Exception {
        if (name == null || password == null || roleStr == null) {
            usage("For -table ecuser you must provide -name, -password, -role");
            return;
        }
        int role;
        try {
            role = Integer.parseInt(roleStr);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Role must be an integer (1,2,3). Got: " + roleStr);
        }
        String digest = md5Hex(password);

        String sql = "INSERT INTO ecuser(name, password, role) VALUES (?, ?, ?)";

        try (Connection cx = DBUtil.getConnection();
             PreparedStatement ps = cx.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, digest);
            ps.setInt(3, role);
            int n = ps.executeUpdate();
            Long id = null;
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) id = rs.getLong(1);
            }
            System.out.println("Inserted into ecuser rows=" + n + " id=" + id + " name=" + name + " role=" + role);
        }
    }

    private static void insertModel(String name, String modelFile, String classNameOverride) throws Exception {
        if (name == null || modelFile == null) {
            usage("For -table ecmodel you must provide -name, -modelfile <path>");
            return;
        }

        File f = new File(modelFile);
        if (!f.isFile()) throw new IllegalArgumentException("Model file not found: " + f.getAbsolutePath());

        byte[] bytes = new byte[(int) f.length()];
        try (FileInputStream fis = new FileInputStream(f)) {
            int read = fis.read(bytes);
            if (read != bytes.length) throw new IllegalStateException("Could not read full file");
        }

        // Try to discover the class name by deserializing (if it's a Java-serialized object)
        String detectedClass = "java.lang.Object";
        if (classNameOverride != null && !classNameOverride.isEmpty()) {
            detectedClass = classNameOverride;
        } else {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
                Object obj = ois.readObject();
                detectedClass = obj.getClass().getName();
            } catch (Throwable t) {
                // Not a serialized object — keep default; still store raw bytes
            }
        }

        String sql = "INSERT INTO ecmodel(name, object, classname, date) VALUES (?, ?, ?, NOW())";

        try (Connection cx = DBUtil.getConnection();
             PreparedStatement ps = cx.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setBytes(2, bytes);
            ps.setString(3, detectedClass);
            int n = ps.executeUpdate();
            Long id = null;
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) id = rs.getLong(1);
            }
            System.out.println("Inserted into ecmodel rows=" + n + " id=" + id + " name=" + name + " class=" + detectedClass);
        }
    }

    private static String md5Hex(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] dig = md.digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder(dig.length * 2);
        for (byte b : dig) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static String next(String[] a, int i) {
        return (i < a.length) ? a[i] : null;
    }

    private static void usage(String msg) {
        System.out.println("ERROR: " + msg);
        System.out.println("Usage:");
        System.out.println("  Insert user:  -table ecuser  -name <name>  -password <pwd>  -role <1|2|3>");
        System.out.println("  Insert model: -table ecmodel -name <name>  -modelfile <path> [-classname <fqcn>]");
        System.out.println("Example MD5(cp630) = 47c9d881d6f747bbc20c48c9a5762f99");
    }
}
