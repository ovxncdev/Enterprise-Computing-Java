package ec.asgmt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.LinkedHashMap;
import java.util.Map;

public class StatsDBDelete {

    // Same connection helper as the other tools
    private static Connection getConnection() throws Exception {
        String url  = System.getenv().getOrDefault("CP630_DB_URL",
                "jdbc:mysql://localhost:3306/cp630?useSSL=false&serverTimezone=UTC");
        String user = System.getenv().getOrDefault("CP630_DB_USER", "root");
        String pass = System.getenv().getOrDefault("CP630_DB_PASS", "");
        return DriverManager.getConnection(url, user, pass);
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> p = parseArgs(args);
        String table = req(p, "table");
        String name  = req(p, "name");

        try (Connection cn = getConnection()) {
            int rows;
            if ("ecuser".equalsIgnoreCase(table)) {
                rows = deleteUser(cn, name);
                System.out.printf("Deleted from ecuser rows=%d name=%s%n", rows, name);
            } else if ("ecmodel".equalsIgnoreCase(table)) {
                rows = deleteModel(cn, name);
                System.out.printf("Deleted from ecmodel rows=%d name=%s%n", rows, name);
            } else {
                throw new IllegalArgumentException("Unsupported table: " + table + " (use ecuser | ecmodel)");
            }
        }
    }

    private static int deleteUser(Connection cn, String name) throws Exception {
        String sql = "DELETE FROM ecuser WHERE name = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate();
        }
    }

    private static int deleteModel(Connection cn, String name) throws Exception {
        String sql = "DELETE FROM ecmodel WHERE name = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate();
        }
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i < args.length; i++) {
            if (args[i].startsWith("-")) {
                String key = args[i].replaceFirst("^-+", "");
                String val = (i + 1 < args.length && !args[i + 1].startsWith("-")) ? args[++i] : "true";
                m.put(key, val);
            }
        }
        return m;
    }

    private static String req(Map<String, String> m, String key) {
        String v = m.get(key);
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing required arg: -" + key);
        }
        return v.trim();
    }
}
