package ec.asgmt.jms;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;

public class StatsJMSProducer {
    public static void main(String[] args) throws Exception {
        String message = arg(args, "-message", "save");
        System.out.println("[Producer] message = " + message);

        Context ctx = null;
        Connection conn = null;
        try {
            System.out.println("[Producer] JNDI…");
            ctx = ContextUtil.getInitialContext();

            System.out.println("[Producer] Lookup RemoteConnectionFactory…");
            ConnectionFactory cf = (ConnectionFactory) ctx.lookup("jms/RemoteConnectionFactory");

            System.out.println("[Producer] Lookup queue…");
            // exported JNDI name (no java:/ prefix) for remote clients
            Destination q = (Destination) ctx.lookup("jms/queue/StatsQueue");

            System.out.println("[Producer] Create connection/session…");
            conn = cf.createConnection("quickstartUser", "quickstartPwd1!");
            Session session = conn.createSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            MessageProducer producer = session.createProducer(q);
            TextMessage msg = session.createTextMessage(message);

            conn.start();
            producer.send(msg);
            System.out.println("[Producer] Sent to StatsQueue: " + message);
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception ignore) {}
            try { if (ctx != null) ctx.close(); } catch (Exception ignore) {}
            System.out.println("[Producer] Done.");
        }
    }

    private static String arg(String[] a, String key, String def) {
        for (int i = 0; i < a.length - 1; i++) if (key.equals(a[i])) return a[i+1];
        return def;
    }
}
