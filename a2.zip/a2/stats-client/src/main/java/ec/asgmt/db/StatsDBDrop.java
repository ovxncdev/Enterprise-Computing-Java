package ec.asgmt.db;

import java.sql.Connection;
import java.sql.Statement;

public class StatsDBDrop {
    public static void main(String[] args) throws Exception {
        try (Connection cx = DBUtil.getConnection();
             Statement st = cx.createStatement()) {

            // Drop in this order (no FKs, but safe if added later)
            st.executeUpdate("DROP TABLE IF EXISTS ecmodel");
            st.executeUpdate("DROP TABLE IF EXISTS ecuser");

            System.out.println("Dropped tables: ecmodel, ecuser (if existed).");
        }
        System.out.println("StatsDBDrop completed.");
    }
}
