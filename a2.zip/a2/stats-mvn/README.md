# Stats Maven Project (stats-mvn)
Author: Adeniyi Ridwan Adetunji  
Date: 2025-10-09

## This project is to demonstrate the following
1. A Maven project to compute simple descriptive statistics (count, min, max, mean, standard deviation) using both incremental and batch algorithms.
2. Create an interface Statistics. 
3. Create a class ECStatistics to implement the interface.
4. Create a class StatisticsTest.java for unit test of the implementation class.
5. Create an application class containing the main method and instantiation of the implementation class and method calls. 
6. Create runtime logging with log4j.
7. Test markdown for simple documentation, like this readme file.

## Prerequisites

1. Java
2. Maven

## Do the following to know this project
 
1. Open and read Statistics.java in the src / ec.asgmt (i.e. src/ec/asgmt/junit directory)
2. Open and read the ECStatistics.java 
3. Open and read the StatisticsTest.java  in test/ec.asgmt. 
4. Run StatisticsTest.java to get the test values.
5. Open and read MyStatistics.java. 
6. Check the lib folder, it contains the jar file libraries for junit, log4j
7. Open cmd console, cd to the root directory, run command: 
mvn clean package
java -jar target/stats-mvn.jar
   
   The output and log info will be on the terminal. A logs folder will be created and the log file app-info.log will be stored in logs. Run the above command again, you can see the logging information in app-info.log file.  
8. Check the log4j configuration file resource/log4j2.xml, and check the log file in logs folder.

   
