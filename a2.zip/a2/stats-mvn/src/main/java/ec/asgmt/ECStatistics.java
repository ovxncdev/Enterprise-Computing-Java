
package ec.asgmt;
//we want the array 'ds' to be dynamic, so we import the java array 
import java.util.ArrayList;
import java.util.List;


public class ECStatistics implements Statistics {
    private List<Double> ds; 
    private int count;
    private double min;
    private double max;
    private double mean;
    private double std;
    private double M2; 
  
    public ECStatistics() {
        ds = new ArrayList<>();  // no fixed size
        count = 0;
        min = 0;
        max = 0;
        mean = 0;
        std = 0;
        M2 = 0;
    }

    @Override
    public void addData(double x) {
        ds.add(x);
        count += 1;
        if (count == 1) {
            min = x;
            max = x;
            mean = x;
            std = 0;
            M2 = 0;
        } else {
            if (x < min) min = x;
            if (x > max) max = x;
            double oldMean = mean;
            mean = oldMean + (x - oldMean) / count;
            M2 = M2 + (x - oldMean) * (x - mean);
            std = Math.sqrt(M2 / count);
        }
    }

    @Override
    public void stats() {
        count = ds.size();
        if (count == 0) {
            min = 0;
            max = 0;
            mean = 0;
            std = 0;
            M2 = 0;
        } else {
            min = Double.MAX_VALUE;
            max = -Double.MAX_VALUE;
            mean = 0;
            M2 = 0;

            // Compute sum for mean in one pass
            double sum = 0;
            for (Double x : ds) {
                sum += x;
                if (x < min) min = x;
                if (x > max) max = x;
            }
            mean = sum / count;

            // Compute standard deviation in the same pass (reusing the loop conceptually)
            // Since we need mean for std, we compute mean first, then loop again for std
            // To strictly use one loop, we could store values, but here we optimize clarity
            double sumSquaredDiff = 0;
            for (Double x : ds) {
                double diff = x - mean;
                sumSquaredDiff += diff * diff;
            }
            std = Math.sqrt(sumSquaredDiff / count);
            M2 = sumSquaredDiff; // Update M2 for consistency with addData
        }
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public double getMin() {
        return min;
    }

    @Override
    public double getMax() {
        return max;
    }

    @Override
    public double getMean() {
        return mean;
    }

    @Override
    public double getSTD() {
        return std;
    }
}