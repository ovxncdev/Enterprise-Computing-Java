package ec.asgmt;

public interface Statistics{

void addData(double x); //: Add a double data value to data structure.  
void stats(); //Compute the descriptive statistics.
int getCount(); //Return the number of data elements in the data structure.
double getMin(); //Return the minimum value.
double getMax(); //Return maximum value.
double getMean(); //Return the average value.
double getSTD(); //Return the standard deviation of the data values. 

}